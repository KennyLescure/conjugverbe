package date;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class Calendrier extends GregorianCalendar
{




/**
     * 
     */
    public Calendrier()
    {
    super();
    // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     * @param arg2
     * @param arg3
     * @param arg4
     * @param arg5
     */
    public Calendrier(int arg0, int arg1, int arg2, int arg3, int arg4, int arg5)
    {
    super(arg0, arg1, arg2, arg3, arg4, arg5);
    // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     * @param arg2
     * @param arg3
     * @param arg4
     */
    public Calendrier(int arg0, int arg1, int arg2, int arg3, int arg4)
    {
    super(arg0, arg1, arg2, arg3, arg4);
    // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     * @param arg2
     */
    public Calendrier(int arg0, int arg1, int arg2)
    {
    super(arg0, arg1, arg2);
    // TODO Auto-generated constructor stub
    }

    public Calendrier(GregorianCalendar calendar)
    {
    super(calendar.get(YEAR), calendar.get(MONTH), calendar.get(DAY_OF_MONTH));
    // TODO Auto-generated constructor stub
    }

    
    /**
     * @param arg0
     */
    public Calendrier(Locale arg0)
    {
    super(arg0);
    // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     */
    public Calendrier(TimeZone arg0, Locale arg1)
    {
    super(arg0, arg1);
    // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     */
    public Calendrier(TimeZone arg0)
    {
    super(arg0);
    // TODO Auto-generated constructor stub
    }

    
/* (non-Javadoc)
     * @see java.util.GregorianCalendar#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj)
    {
    if (!( obj instanceof Calendrier)) return false;
    return super.equals(obj);
    }

public  String toString()
{
 return 
 Integer.toString(this.get(Calendar.YEAR))+
"-"+(1+this.get(Calendar.MONTH))+
"-"+this.get(Calendar.DAY_OF_MONTH);

}

}//Calendrier
