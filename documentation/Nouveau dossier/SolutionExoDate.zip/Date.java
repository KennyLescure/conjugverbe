package date;

/**
 * 
 * repr�sente une date du calendrier; par exemple : lundi 20 mars 2006
 * 
 * @author Dominique Michel
 * */
public class Date
{
//---------------- classe Date -----------------------

private int         jour;  // n� du jour dans le mois 
private Mois        mois;
private int         annee;
private JourSemaine jourSemaine;


/**
 * @param jMois repr�sentant un n� de jour dans le mois mois
 * @param mois repr�sentant un mois
 * @param ann�e repr�sentant l'ann�e � laquelle appartient mois
 * @param jSemaine repr�sentant le jour de semaine correspondant aux 3 param�tres pr�c�dents
 *
 * @throws une IndexOutOfBoundsException si jMois n'est pas dans {1...longueur(mois)}
 * */
public Date( int jMois, Mois mois, int ann�e, JourSemaine jSemaine) throws IndexOutOfBoundsException    // jm >=1
    {
    int n = mois.longueur(ann�e);

    if ((jMois<1) || (jMois>n))
       throw new IndexOutOfBoundsException("Date mal construite");
    
    jour = jMois; this.mois = mois; this.annee = ann�e; jourSemaine = jSemaine;

    }


/**
 * @param j repr�sentant un n� de jour dans le mois m
 * @param m repr�sentant un mois d�fini par l'une des constantes litt�rales de la classe Mois
 * @param a repr�sentant l'ann�e � laquelle appartient m
 * @param js repr�sentant le jour de semaine d�fini par l'une des constantes litt�rales de la classe JourSemaine
 *
 * @throws une IndexOutOfBoundsException si la date n'est pas valide
 * */
public 
Date(int j, int m, int a, int js) throws IndexOutOfBoundsException  // j >=1,  0<= m <= 11, 0 <= js <= 6
    {
    this( j, new Mois(m), a, new JourSemaine(js));
    }



/**
 * @param j repr�sentant un n� de jour dans le mois m
 * @param m repr�sentant un mois d�fini par une cha�ne de la forme "janvier" ou "MARS" ou "  JuiLLeT   "
 * @param a repr�sentant l'ann�e � laquelle appartient m
 * @param js repr�sentant un jour de semaine d�fini par une cha�ne de la forme "lundi" ou "MARDI" ou "  MerCreDI   "
 *
 * @throws une IndexOutOfBoundsException si la date n'est pas valide
 * 
 * */
public 
Date(int j, String m, int a, String js) throws IndexOutOfBoundsException  
    // j >=1,  "janvier"<= m <= "d�cembre",  "lundi" <= js <= "dimanche"
    // les majuscules sont accept�es
    {
    this( j, new Mois(m), a, new JourSemaine(js));
    }


public Date suivante()
{
    int jour1, annee1, n;
    Mois mois1;

    jour1 = jour; mois1 = mois; annee1 = annee; n = mois.longueur(annee);

    if (jour < n)
       ++jour1;
    else    // jour est le dernier jour du mois
       {
       jour1 = 1; mois1 = mois1.suivant();
       if (mois.estEgal(new Mois(Mois.DECEMBRE)))
            ++annee1;
       }
    return new Date(jour1, mois1, annee1, jourSemaine.suivant());
}

public Date precedente()
    {
    int jour1, annee1;
    Mois mois1;

    jour1 = jour; mois1 = mois; annee1 = annee;

    if (jour1 >= 2)
       --jour1;
    else    // jour est le 1er jour du mois
       {
       mois1 = mois1.precedent();
       
       if (mois1.estEgal(new Mois(Mois.DECEMBRE)))
          --annee1;
       
       jour1 = mois1.longueur(annee1);
       
       }
    return new Date(jour1, mois1, annee1, jourSemaine.precedent());
    }
    

public String toString()
    {
    return jourSemaine.toString()+" "+
    Integer.toString(jour)+" "+mois.toString()+" "+Integer.toString(annee);
    }

public JourSemaine jourSemaine() {return jourSemaine;}
public int jour() {return jour;}
public Mois mois() {return mois;}
public int annee() {return annee;}



//---------------- classe Date -----------------------
}
