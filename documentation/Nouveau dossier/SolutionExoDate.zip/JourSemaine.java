package date;

/**
 * 
 * repr�sente un jour de semaine
 * 
 * @author Dominique Michel
 * */
public class JourSemaine
{
//------------------ classe JourSemaine -------------------

private int j;  //  0 <=j <= 6. 0<-->LUNDI

private final static 
String [] ch = {"LUNDI","MARDI","MERCREDI","JEUDI","VENDREDI","SAMEDI","DIMANCHE"};

public final static int LUNDI    = 0;
public final static int MARDI    = 1;
public final static int MERCREDI = 2;
public final static int JEUDI    = 3;
public final static int VENDREDI = 4;
public final static int SAMEDI   = 5;
public final static int DIMANCHE = 6;

/**
 * @param j v�rifiant 0 <= j <= 6. 0 correspondant � Lundi
 * On suppose que j est une des 7 constantes litt�rales LUNDI...DIMANCHE
 * @throws une IndexOutOfBoundsException si j n'est pas dans {0..6}
 * */
public JourSemaine (int j) throws IndexOutOfBoundsException // on suppose 0 <= j <= 6. 0 <-->LUNDI
    {
    if ((j<0)||(j>6)) 
        throw new IndexOutOfBoundsException("JourSemaine (int j): j n'est pas dans {0..6}");
    this.j = j;
    }


/**
 * @param s 
 * On suppose que s est de la forme "lundi" ou "MARDI" ou "  MerCreDI   "
 * @throws une IndexOutOfBoundsException si s ne repr�sente pas un jour de semaine
 * */
public JourSemaine (String s) throws IndexOutOfBoundsException // on suppose que s est "lundi" ou ..."dimanche"
    {
    this(Operations.index(s.trim(),ch));
    }

public String toString() {return ch[j];}

public JourSemaine suivant()
{
return new JourSemaine((j+1)%7);
}
    
public JourSemaine precedent()
{
return new JourSemaine((j+6)%7);
}

//------------------ classe JourSemaine -------------------
}

