package date;

/**
 * 
 * 
 * 
 * repr�sente un mois de l'ann�e
 * 
 * @author Dominique Michel
 * 
 * */
public class Mois
{
//---------------- classe Mois -----------------------

private int m; // de 0 � 11. 0 <-->JANVIER


private final static 
String [] ch = {"JANVIER","F�VRIER","MARS","AVRIL","MAI","JUIN",
        "JUILLET","A�UT","SEPTEMBRE","OCTOBRE","NOVEMBRE","D�CEMBRE"};


private final static 
int [] longueurs = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

public final static int JANVIER    =  0;
public final static int FEVRIER    =  1;
public final static int MARS       =  2;
public final static int AVRIL      =  3;
public final static int MAI        =  4;
public final static int JUIN       =  5;
public final static int JUILLET    =  6;
public final static int AOUT       =  7;
public final static int SEPTEMBRE  =  8;
public final static int OCTOBRE    =  9;
public final static int NOVEMBRE   = 10;
public final static int DECEMBRE   = 11;



/**
 * @param m v�rifiant 0 <= m <= 11. 0 correspondant � Janvier
 * On suppose que m est une des 12 constantes litt�rales JANVIER...DECEMBRE
 * @throws une IndexOutOfBoundsException si m n'est pas dans {0..11}
 * */
public Mois (int m) throws IndexOutOfBoundsException // on suppose 0 <= m <= 11. 0 <-->JANVIER
    {
    if ((m<0)||(m>11)) 
        throw new IndexOutOfBoundsException("Mois (int m): m n'est pas dans {0..11}");
    this.m = m;
    }


/**
 * @param s 
 * On suppose que s est de la forme "janvier" ou "MARS" ou "  JuiLLeT   "
 * @throws une IndexOutOfBoundsException si s ne repr�sente pas un mois de l'ann�e
 * */
public Mois (String s) throws IndexOutOfBoundsException // on suppose que s est "janvier" ou ..."d�cembre"
    {
    this(Operations.index(s.trim(),ch)); 
    }

public boolean estEgal(Mois mois) {return (m == mois.m);}

public String toString() {return ch[m];}

public Mois suivant()
    {
    return new Mois((m+1)%12);
    }
    
public Mois precedent()
    {
    return new Mois((m+11)%12);
    }


/**
 * @param ann�e : l'ann�e � la quelle appartient ce mois
 * @return le nombre de jours de ce mois
 * */
public int longueur(int ann�e)      //renvoie le nombre de jours de ce mois
    {
    if ((m == FEVRIER) && Operations.estBissextile(ann�e))  
       return 29;
    else        
       return longueurs[m];
    }

//---------------- classe Mois -----------------------
}
