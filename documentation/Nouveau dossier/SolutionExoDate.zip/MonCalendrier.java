package date;

import java.util.*;

public class MonCalendrier extends GregorianCalendar
{

public String toString()
{
return Integer.toString(super.get(Calendar.YEAR))+
"-"+super.get(Calendar.MONTH)+
"-"+super.get(Calendar.DAY_OF_MONTH);

}

}//MonCalendrier
