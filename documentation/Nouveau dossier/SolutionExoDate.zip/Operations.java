package date;

/**
 * 
quelques m�thodes utiles aux classes du package date

@author Dominique Michel
 * */
public class Operations
{
//------------------- Operations ----------------------------

/** @param c cha�ne de caract�res quelconque
 * @param t tableau de cha�nes dans lequel on recherche c
 * recherche si c est dans le tableau t. suppose que t contient au moins 1 elt
 *  @return 
renvoie i tel que c == t[i] ou bien -1 si c n'est pas dans t. la recherche ignore la distinction 
majuscule/minuscule */
public static int index(String c, String [] t)

    {
    int i = 0;
    while (i<t.length)
        {
        if (c.equalsIgnoreCase(t[i]))
            return i;
        ++i;
        } 
    return -1;
    }


/**
 * @param ann�e suppos�e repr�senter une ann�e 
 * @return true si ann�e est une ann�e bissextile, false sinon 
 */
public static boolean estBissextile(int ann�e)
    {
    return (( ann�e%4 == 0 ) && ( ann�e%100 != 0 ));    // quelque chose dans ce go�t l�
    }

//---------------------- Operations ---------------------------
}
