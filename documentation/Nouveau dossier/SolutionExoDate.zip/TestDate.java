package date;

public class TestDate
{
public static void main(String [] arg) throws Exception
{
JourSemaine j1, j2, j3, j4;

j1 = new JourSemaine(" dimAnCHE");

j2 = new JourSemaine(JourSemaine.MARDI);

System.out.println(" j2  = "+ j2); // mardi

j3 = j2.precedent().suivant();

System.out.println(" j3  = "+ j3); // mardi

j4 = new JourSemaine(4);  //tr�s maladroit : cr�ation de vendredi

System.out.println("j4 = " + j4); //vendredi

System.out.println(j1); //dimanche

j1 = j1.suivant();
System.out.println(j1); //lundi

j1 = j1.suivant();
System.out.println(j1); //mardi

j1 = j1.suivant();
System.out.println(j1); //mercredi
j1 = j1.suivant();
System.out.println(j1); //jeudi
j1 = j1.suivant();  //vendredi

j1 = j1.suivant();  //samedi

j1 = j1.suivant();  //dimanche

j1 = j1.suivant();  //lundi

System.out.println(j1); //lundi

Date d1, d2, d3;

d1 = new Date(20, "  maRS  ", 2006, " lUnDi ");

d2 = d1.suivante();
d3 = d1.precedente();
System.out.println("aujourd'hui = "+d1);
System.out.println("demain = "+d2);
System.out.println("hier = "+d3);


} // main
} // TestDate
