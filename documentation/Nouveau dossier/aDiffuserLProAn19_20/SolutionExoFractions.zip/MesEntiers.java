package fractions;

/**
 * fonctions utiles pour le type int
 */
 
public class MesEntiers
{
//------------------ classe MesEntiers --------------------

private static int pgcd( int a, int b) // suppose a >=1 et b >= 1
{
if ( a == b) 
    return a;
else
    if (a > b)
        return pgcd(a-b,b);
    else
        return pgcd(a, b-a);
}


/**
 * Calcule le plus grand commun diviseur de a et de b
 * exemple : si a = -48 et b = 32 alors le pgcd est 16 car -48 = -3x16 et 32 = 2x16 
 *  a et b ne doivent pas �tre simultan�ment nuls
 * @param a n'importe quelle valeur enti�re
 * @param b n'importe quelle valeur enti�re
 * @return le plus grand diviseur commun � a et b
 */
 
public static int pGCD(int a, int b) // suppose (a,b) != (0,0)
{
if (a == 0)
    return Math.abs(b);
else /* a != 0 */
    if ( b == 0)
        return Math.abs(a);
    else /* a et b sont non nuls */
        return pgcd(Math.abs(a), Math.abs(b));
}

/*
 * calcule le PGCD de a et b par l'algorithme d'Euclide.
 * 
 * @param a tel que a >= 0
 * @param b tel que b >= 1
 * 
 * */
private static int pgcd1(int a, int b)
{
if (b == 0) return a;
else
    return pgcd1(b, a%b);
}


/**
 * calcule le PGCD de a et b par l'algorithme d'Euclide.
 * 
 * */
public static int pGCD1(int a, int b)
{
int va, vb;

va = Math.abs(a);
vb = Math.abs(b);

if ( va >= vb)
    return pgcd1(va,vb);
else 
    return pgcd1 (vb, va);
}


//------------------ classe MesEntiers --------------------
}


