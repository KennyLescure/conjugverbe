package fractions;

/**
 * La classe Syst�me g�re la r�solution de syst�mes lin�aires de deux �quations � deux inconnues
 * 
 * 
 */
public class Syst�me
{
//---------------- classe Syst�me ----------------------

/**
 * calcule le d�terminant :
 * 
 * | a11 a12 |  
 *
 * | a21 a22 |  
 * 
 */
public static Fraction d�t( Fraction a11, Fraction a12,
                            Fraction a21, Fraction a22)
{
return a11.produit(a22).diff�rence(a21.produit(a12));
}

/**
 * R�sout le syst�me :
 *   | a1*x + b1*y = c1 
 *   | a2*x + b2*y = c2
 *   
 * @return un tableau t tel que x = t[0] et y = t[1]. t.length = 0 en cas d'absence de solutions ou en cas d'infinit� de solutions
 * 
 */
public static Fraction[] r�sout( Fraction a1, Fraction b1, Fraction c1, 
                                 Fraction a2, Fraction b2, Fraction c2)
{
//----------------------- r�sout ------------------------
try
{
Fraction d;
Fraction [] r;

d = d�t( a1, b1, a2, b2);

r = new Fraction[2];
r[0] = d�t(c1,b1,c2,b2).division(d);
r[1] = d�t(a1,c1,a2,c2).division(d);
return r;
}
catch(Exception e)
{
return new Fraction[0];
}
//----------------------- r�sout ------------------------
}

//---------------- classe Syst�me ----------------------
}
