package fractions;  

/**
 * teste la classe Fraction dans la version non d�finitive avec un constructeur public
 * faisant des tests
 * et non avec la m�thode statique cr��Fraction 
 * 
 * */
public class TestFraction2
{

public static void main(String[] args) // throws Exception // pour �viter de g�rer le bloc catch/try
{
try{
Fraction x1, x2, x3, x4, x5;

x1 = new Fraction(" -3 / 7 ");
x2 = new Fraction(4,-5);
x3 = new Fraction(-7,-5);

System.out.println(" x1 = "+ x1);
System.out.println(" x2 = "+ x2);
System.out.println(" x3 = "+ x3);

x3 = x1.somme(x2);
x4 = x3.diff�rence(x2);
x5 = x4.simplifie();

System.out.println(" x3 = "+ x3);               // doit  afficher x3 = -43/35
System.out.println(" x4 = "+ x4);               // doit afficher x4 = -75/175 (si non simplifi�
System.out.println(" x1 == x4 "+ x1.equals(x4)); // doit afficher true
System.out.println(" x5 = "+ x5);               // doit afficher x5 = -3/7

Fraction a1, b1, c1, a2, b2, c2;
Fraction [] x;

a1 = new Fraction( 2, 5);
b1 = new Fraction( 3, 4);
c1 = new Fraction( 1, 20);
a2 = new Fraction( 7, 3);
b2 = new Fraction( 4, 11);
c2 = new Fraction( 142, 33);
//a2 = a1; b2 = b1;

x = Syst�me.r�sout( a1, b1, c1, a2, b2, c2);

if (x.length == 0)
    System.out.println(" pas de solution");
else
    System.out.println(" x = "+ x[0]+ " y = "+ x[1]);
    
}// try
catch(ArithmeticException e){System.err.println("une fraction est mal construite");}
}
}

