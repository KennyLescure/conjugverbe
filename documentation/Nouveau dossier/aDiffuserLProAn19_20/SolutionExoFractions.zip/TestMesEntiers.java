package fractions;

public class TestMesEntiers
{

/**
 * @param args
 */
public static void main(String[] args)
{

int a, b, c;


System.out.println(" pGCD(13*289, 13*931)  = " +MesEntiers.pGCD(13*289, 13*931));

System.out.println(" pGCD(13*-289, 13*931)  = " +MesEntiers.pGCD(13*-289, 13*931));

System.out.println(" pGCD(13*289, 13*-931)  = " +MesEntiers.pGCD(13*289, 13*-931));

System.out.println(" pGCD(13*-289, 13*-931)  = " +MesEntiers.pGCD(13*-289, 13*-931));

System.out.println(" pGCD(-71, 0)  = " +MesEntiers.pGCD(-71, 0));

System.out.println(" pGCD(0, -29)  = " +MesEntiers.pGCD( 0, -29));

System.out.println(" pGCD(13*289, 13*931)  = " +MesEntiers.pGCD1(13*289, 13*931));

System.out.println(" pGCD(13*-289, 13*931)  = " +MesEntiers.pGCD1(13*-289, 13*931));

System.out.println(" pGCD(13*289, 13*-931)  = " +MesEntiers.pGCD1(13*289, 13*-931));

System.out.println(" pGCD(13*-289, 13*-931)  = " +MesEntiers.pGCD1(13*-289, 13*-931));

System.out.println(" pGCD(-71, 0)  = " +MesEntiers.pGCD1(-71, 0));

System.out.println(" pGCD(0, -29)  = " +MesEntiers.pGCD1( 0, -29));

}

}
