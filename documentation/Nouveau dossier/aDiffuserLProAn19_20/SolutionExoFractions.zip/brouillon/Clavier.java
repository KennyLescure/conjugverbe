package fractions.brouillon;

import java.io.*;

import fractions.Fraction;
/**
 * G�re les saisies formatt�es les plus courantes au clavier
 */
public class Clavier
{
//--------------------------- classe Clavier ---------------------------------------

/**
 * Lit la prochaine ligne au clavier. s'arr�te sur une fin de ligne. La s�quence de caract�res de fin de ligne n'est pas incluse dans la cha�ne r�sultat
 * @return la cha�ne lue au clavier
 */
public static String lireLigne() throws IOException
{
//--------------------------- lireLigne() ---------------------------------------

int c;
String s;

c = System.in.read();
s = "";
while (c >=0 && c != '\n')
    {
    s+=(char)c;
    c = System.in.read();
    }
return s;

//--------------------------- lireLigne() ---------------------------------------
}

/**
 * Lit le prochain mot au clavier. s'arr�te sur un espace, une tabulation ou une fin de ligne. La s�quence de caract�res de fin de mot n'est pas incluse dans la cha�ne r�sultat
 * @return le mot lu au clavier
 */
public static String lireMot() throws IOException
{
//--------------------------- lireMot() ---------------------------------------

int c;
String s;

c = System.in.read();
s = "";
while (c >=0 && c != '\n' && c!=' ' && c != '\t')
    {
    s+=(char)c;
    c = System.in.read();
    }
return s;

//--------------------------- lireMot() ---------------------------------------
}

/**
 * Lit le prochain entier au clavier. 
 * @return le nombre entier lu  au clavier
 */
public static int lireInt() throws IOException, NumberFormatException
{
//--------------------------- lireInt() ---------------------------------------

int n;
String s;

s = lireMot();
s = s.trim(); /* enl�ve les �ventuels espaces de t�te ou de fin */
n = new Integer(s).intValue();
return n;

//--------------------------- lireInt() ---------------------------------------
}


/**
 * Lit la prochaine Fraction au clavier. Le num�rateur et le d�nominateur doivent �tre s�par�s au moins par un espace 
 * @return la fraction lue  au clavier
 */
public static Fraction lireFraction() throws IOException, NumberFormatException 
{
//--------------------------- lireFraction() ---------------------------------------

int a,b;

a = lireInt(); b = lireInt();

return Fraction.cr�eFraction(a,b).simplifie();

//--------------------------- lireFraction() ---------------------------------------
}

//--------------------------- classe Clavier ---------------------------------------
}

