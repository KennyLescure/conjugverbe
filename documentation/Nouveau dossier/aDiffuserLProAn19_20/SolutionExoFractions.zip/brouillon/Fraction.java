package fractions.brouillon;

import java.io.*;

/**
 * La classe Fraction repr�sente un entier rationnel
 * @author  Dominique Michel
 */
public class Fraction implements Serializable
{
// ------------ Fraction -------------------------

/**
 * @uml.property  name="num"
 */
private int num;

/**
 * @uml.property  name="den"
 */
private int den; // den >= 1

/**
 * la valeur 0 sous la forme du nombre rationnel 0/1
 */
public static final Fraction ZERO = new Fraction(0,1); 

/**
 * cr�e la Fraction a/b. b doit �tre non nul. 
 * 
 * @param a : entier quelconque
 * @param b : entier non nul
 * 
 * @exception Lance une ArithmeticException si b est nul 
 */
public static Fraction cr�eFraction(int a, int b) throws ArithmeticException// suppose
                                                                            // b !=
                                                                            // 0
{
// ------------ cr�eFraction -------------------------
Fraction f = new Fraction(0,1);
f.set(a,b);
return f;

// ------------ cr�eFraction -------------------------
}

/**
 * @param a : entier quelconque
 * @param b : entier non nul
 * 
 * remplit correctement num et den avec a et b de fa�on � former a/b. b doit �tre non nul. 
 * @exception Lance une ArithmeticException si b est nul 
 * 
 * !! ATTENTION !!
 * ce constructeur est �limin� dans la version finale (optimis�e) et est remplac� par 
 * le constructeur suivant qui est priv� etr ne fait aucun test
 * 
 */

/**/
public Fraction(int a, int b)throws ArithmeticException
{
//------------ Fraction -------------------------

this.set(a, b);

//------------ Fraction -------------------------
}
/**/

/*
 * 
 * ce constructeur reste et remplace l'autre de m�me signature dans la version finale optimis�e
 * 
 * */

/* * /
private Fraction(int a, int b) // pas de tests
{
this.num = a;
this.den = b;
}
/ * */

/**
 * remplit correctement num et den avec a et b de fa�on � former a/b. b doit �tre non nul. 
 * @exception Lance une ArithmeticException si b est nul 
 */
private void set(int a, int b)throws ArithmeticException
{
//------------ set -------------------------

if (b == 0)
    throw new ArithmeticException("d�nominateur nul");

if (b > 0)
    {num = a; den = b;}
else
    {num = -a; den = -b;}

//------------ set -------------------------
}


/**
 * cr�e une fraction � partir d'une cha�ne de caract�re
 * @param s doit �tre au format nombre entier sign�/nombre entier sign� non nul
 * exemple "-3/5"
 * @throws si s ne respecte pas le format indiqu�
 * */
public Fraction(String s)throws ArithmeticException, NumberFormatException
{
int d;

d  = s.indexOf('/');
if (d<0) throw new NumberFormatException("/ manquant");
String snum, sden;

snum = s.substring(0,d).trim(); sden = s.substring(d+1).trim();

int a, b;

a = new Integer(snum).intValue();
b = new Integer(sden).intValue();
this.set(a,b);
}

/**
 * @return la version String de this. 
 * Le num�rateur et le d�nominateur sont s�par�s par un /
 */
public String toString()
{
return Integer.toString(num) + "/" + Integer.toString(den);
}




/**
 * @return the num
 */
public int getNum()
{
return num;
}

/**
 * @return the den
 */
public int getDen()
{
return den;
}

/**
 * @return this + x
 * 
 */
public Fraction somme(Fraction x) // calcule this + x
{
return new Fraction(num*x.den+den*x.num,den*x.den).simplifie();
}

/**
 * @return -this
 */
public Fraction oppos�()    // calcule -this 
{
return new Fraction(-num,den);
}

/**
 * @return this - x
 */
public Fraction diff�rence(Fraction x) // calcule this - x
{
return this.somme(x.oppos�());
}

/**
 * 
 * @return true si x est une Fraction et si this et x sont �gales math�matiquement,
 * false sinon. Exemple : renvoie true si this = -2/3 et x = -6/9
 */
public boolean equals(Object x)
{
if (x instanceof Fraction)
    {
    Fraction r = (Fraction)x;
    return num*r.den == den*r.num;
    }
else
    return false;
}

/**
 * @return this * x
 */
public Fraction produit(Fraction x) // calcule this * x
{
return new Fraction(num*x.num,den*x.den).simplifie();
}

/**
 * lance une ArithmeticException si this est nul
 * @return 1/this
 */
public Fraction inverse()throws ArithmeticException
{
return cr�eFraction(den,num);
}

/**
 * lance une ArithmeticException si x est nul
 * @return this / x
 */
public Fraction division(Fraction x) throws ArithmeticException // calcule this/x
{
return this.produit(x.inverse());
}

/**
 * @return a/b telle que a/b = this et a et b premiers entre eux
 */
public Fraction simplifie()
{
int d = MesEntiers.pGCD(num,den);
return new Fraction(num/d,den/d);
}
// ------------ Fraction -------------------------
}

