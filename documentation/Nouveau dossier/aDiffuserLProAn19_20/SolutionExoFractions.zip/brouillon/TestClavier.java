package fractions.brouillon;

import fractions.Fraction;


public class TestClavier
{
public static void main(String[]args) throws Exception
{
String s, mot;
int i;
Fraction x;

System.out.println("tapez une phrase");
s = Clavier.lireLigne();
System.out.println(" la phrase tap�e est : "+s);

System.out.println("tapez un mot");
mot = Clavier.lireMot();
System.out.println(" le mot tap� est : "+mot);

System.out.println("tapez un entier");
i = Clavier.lireInt();
System.out.println(" le nombre entier tap� est : "+i);

System.out.println("tapez une fraction (laissez au moins un espace entre le num�rateur et le d�nominateur)");
x = Clavier.lireFraction();
System.out.println(" la fraction tap�e est : "+x);

}
}