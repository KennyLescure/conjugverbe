package exemplecoursstate;

import injectiondecode.mieux.Operation;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import exemplecoursstate.controleurs.*;
import exoportequisouvre.vues.Outils;

/**
 * Calculette rudimentaire : effectue une op�ration x op y o� 0 <= x <= 9 et 0 <= y <= 9 et op est dans {+,*}
 * 
 * x, y et op peuvent �tre indiqu�s par frappe du clavier physique ou virtuel
 * 
 * */
public class CalculetteState extends Frame implements ActionListener, KeyListener
{
R�sultat r�sultat; // pour montrer le calcul en cours
Pav� pav�;          // clavier virtuel
Terminaison terminaison;    // pour quitter l'appli


/*------------------ pour g�rer le diagramme de transition d'�tat -------------------*/

Controleur1erOperande contr�leur1erOp�rande;    // associ� � l'�tat "d�signation 1er op�rande"
ControleurOperateur contr�leurOp�rateur;        // associ� � l'�tat "d�signation op�rateur"
Controleur2emeOperande contr�leur2�meOp�rande;  // associ� � l'�tat "d�signation 2�me op�rande"
ControleurEtat contr�leurCourant;               // le contr�leur courant qui "voyage" dans le graphe orient�

int x,y;                // les deux op�randes du calcul
Operation op�ration;    // l'op�ration � effectuer sur les op�randes


public CalculetteState(String arg0) throws HeadlessException
{
super(arg0);
Outils.place(this, 0.33, 0.33, 0.25, 0.5);  // positionne et dimensionne l'appli GUI

//-------------- installation des composants graphiques et de this comme �couteur des boutons et du clavier -----------

this.r�sultat = new R�sultat(this); this.add(this.r�sultat,BorderLayout.NORTH);
this.pav� = new Pav�(this,this); this.add(this.pav�,BorderLayout.CENTER);

// � pr�sent this �coute les �v�nements clavier et les �v�nements bouton

this.installeContr�leurs();

this.terminaison = new Terminaison(this);
}

/*
 * construit le graphe orient� correspondant au diagramme de transition d'�tats.
 * Rappelons que chaque �tat est g�r� par un contr�leur d'�tat.
 * Il faut donc autant de contr�leurs que d'�tats + le contr�leur courant
 * */
private void installeContr�leurs()
{
//---------- instanciation des 3 objets contr�leurs ---------------
this.contr�leur2�meOp�rande = new Controleur2emeOperande(this,null,null);
this.contr�leurOp�rateur= new ControleurOperateur(this,this.contr�leur2�meOp�rande,null);
this.contr�leur1erOp�rande = new Controleur1erOperande(this,this.contr�leurOp�rateur,null);

//--------------------- on �tablit les liens oubli�s entre les contr�leurs ---------------- 

this.contr�leur2�meOp�rande.suivant = this.contr�leur1erOp�rande;
this.contr�leurOp�rateur.retour = this.contr�leur1erOp�rande;
this.contr�leur2�meOp�rande.retour = this.contr�leurOp�rateur;

//-------------------- on place le contr�leur courant sur l'�tat de d�part dans le graphe ----------

this.contr�leurCourant = this.contr�leur1erOp�rande;
}

/* (non-Javadoc)
 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
 */
@Override
public void actionPerformed(ActionEvent arg0)
{
this.contr�leurCourant.actionPerformed(arg0); // on transmet la gestion de l'�v�nement au contr�leur courant
}

/* (non-Javadoc)
 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
 */
@Override
public void keyTyped(KeyEvent arg0)
{
this.contr�leurCourant.keyTyped(arg0);        // on transmet la gestion de l'�v�nement au contr�leur courant
}

public void setR�sultat(String s)
{
this.r�sultat.setText(s);
}

public void compl�teR�sultat(String s)
{
String r = this.r�sultat.getText();
r+=s;
this.r�sultat.setText(r);
}

public void compl�teR�sultat(char c)
{
this.compl�teR�sultat(new Character(c).toString());
}

public void effaceFinR�sultat()
{
String s = this.r�sultat.getText();
int l = s.length();
s = s.substring(0, l-1);
this.r�sultat.setText(s);
}

public int getX() {return this.x;}

public int getY() {return this.y;}

public Operation getOp�ration() {return this.op�ration;}

/**
 * @param contr�leurCourant the contr�leurCourant to set
 */
public void setContr�leurCourant(ControleurEtat contr�leurCourant)
{
this.contr�leurCourant = contr�leurCourant;
}

public void setX(int x) {this.x = x;}

public void setY(int y) {this.y = y;}

public void setOp�ration(Operation op�ration) {this.op�ration = op�ration;}

// ------------------- il est inutile de g�rer les �v�nements suivants ---------------------

/* (non-Javadoc)
 * @see java.awt.event.KeyListener#keyPressed(java.awt.event.KeyEvent)
 */
@Override
public void keyPressed(KeyEvent arg0)
{
// � compl�ter pour donner un effet "bouton enfonc�"
}

/* (non-Javadoc)
 * @see java.awt.event.KeyListener#keyReleased(java.awt.event.KeyEvent)
 */
@Override
public void keyReleased(KeyEvent arg0)
{
// � compl�ter pour donner un effet "bouton relach�"
}

}
