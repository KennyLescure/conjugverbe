package exemplecoursstate;

import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

/**
 * repr�sente le pav� num�rique classique d'une calculette.
 * Montre les  chiffres de 0 � 9, les op�rateurs + et * et la touche 'c' pour retour (ou correction)
 * 
 * Muni de 2 �couteurs d'�v�nements, l'un pour les �v�nements clavier l'autre pour les �v�nements bouton
 * */
public class Pav� extends Panel
{
TouchePav� [][] touches;

/**
 * @param a : �couteur de tous les boutons du pav�
 * @param k : �couteur des �v�nements clavier
 * 
 * */
    public Pav�(ActionListener a, KeyListener k)
    {
    String [][] symboles = {{"1","2","3"},{"4","5","6"},{"7","8","9"},{"+","0","*"},{"c"," "," "}};
    this.touches = new TouchePav�[5][3];
    
    this.setLayout(new GridLayout(5,3));
    
    int i, j;
    
    for (i = 0; i < this.touches.length; ++i)
        for (j = 0; j < this.touches[0].length; ++j)
            this.touches[i][j] = new TouchePav�(symboles[i][j],this,a,k);
    }

}
