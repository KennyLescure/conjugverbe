package exemplecoursstate;

import java.awt.HeadlessException;
import java.awt.TextField;
import java.awt.event.KeyListener;

/**
 * Montre le calcul en cours
 * */
public class R�sultat extends TextField
{

/**
 * @param k : �couteur des �v�nements clavier g�n�r�s par this
 * */
public R�sultat( KeyListener k) throws HeadlessException
{
super("0",10);
this.setEditable(false);
this.addKeyListener(k);
}

}
