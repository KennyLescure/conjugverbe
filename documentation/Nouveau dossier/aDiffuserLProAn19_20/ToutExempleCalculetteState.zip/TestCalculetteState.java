package exemplecoursstate;

/**
 * Exemple d'application tr�s simple mettant en oeuvre le DP State : 
 * calculette rudimentaire
 * */
public class TestCalculetteState
{
public static void main(String[] args)
{
CalculetteState calculette = new CalculetteState("calculette : exemple de mise en oeuvre de DP State");
calculette.setVisible(true);
}
}
