package exemplecoursstate;

import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

/**
 * Repr�sente une touche du clavier virtuel ou pav�
 * */
public class TouchePav� extends Button
{

    /**
     * @param c : libell� de la touche
     * @param pav� : clavier qui va contenir la touche
     * @param a : �couteur des �v�nements action de la touche
     * @param k : �couteur des �v�nements clavier g�n�r�s par la touche
     * 
     * */
    public TouchePav�(String c, Pav� pav�, ActionListener a, KeyListener k)
    {
    super(c);
    pav�.add(this);
    this.addActionListener(a);
    this.addKeyListener(k);
    }
    
public char getSymbole(){ return this.getLabel().charAt(0);}
}
