package exemplecoursstate.controleurs;

import exemplecoursstate.CalculetteState;

/**
 * G�re l'�tat d�signation du 1er op�rande
 * 
 * */
public class Controleur1erOperande extends ControleurOperande
{
public Controleur1erOperande(CalculetteState calculetteState,
        ControleurEtat suivant, ControleurEtat retour)
{
super(calculetteState, suivant, retour);
}

@Override
protected void traiteOp�rande(int x)
{
this.calculetteState.setX(x);
this.calculetteState.setR�sultat(Integer.toString(x));
this.calculetteState.setContr�leurCourant(this.suivant);
}

}
