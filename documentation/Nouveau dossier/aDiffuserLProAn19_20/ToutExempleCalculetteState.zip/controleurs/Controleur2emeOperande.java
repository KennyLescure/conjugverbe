package exemplecoursstate.controleurs;

import exemplecoursstate.CalculetteState;

/**
 * G�re l'�tat d�signation du 2�me op�rande
 * */
public class Controleur2emeOperande extends ControleurOperande
{

public Controleur2emeOperande(CalculetteState calculetteState,
        ControleurEtat suivant, ControleurEtat retour)
{
super(calculetteState, suivant, retour);
}


public void traite(char c)
{
if (this.traiteRetour(c))
    this.calculetteState.setContr�leurCourant(this.retour);
else
    super.traite(c);
}

/* (non-Javadoc)
 * @see exemplecoursstate.controleurs.ControleurOperande#traiteOp�rande(int)
 */
@Override
protected void traiteOp�rande(int x)
{
this.calculetteState.setY(x);
int r = this.calculetteState.getOp�ration().effectue(this.calculetteState.getX(), this.calculetteState.getY());
this.calculetteState.compl�teR�sultat(Integer.toString(x)+"="+r);
this.calculetteState.setContr�leurCourant(this.suivant);
}

}
