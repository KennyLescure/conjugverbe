package exemplecoursstate.controleurs;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import exemplecoursstate.CalculetteState;
import exemplecoursstate.TouchePav�;

/**
 * Classe m�re de tous les contr�leurs d'�tats
 * 
 * */
public abstract class ControleurEtat
{
CalculetteState calculetteState;
public ControleurEtat suivant,retour; // lien vers l'�tat suivant ou vers l'�tat pr�c�dent
/**
 * @param calculetteState
 * @param suivant
 * @param retour
 */
public ControleurEtat(CalculetteState calculetteState, ControleurEtat suivant,
        ControleurEtat retour)
{
this.calculetteState = calculetteState;
this.suivant = suivant;
this.retour = retour;
}

/**
 * 
 * Ceci n'est pas une m�thode �v�nementielle. Elle porte ce nom par commodit�
 *
 * */
public void actionPerformed(ActionEvent arg0)
{
TouchePav� touche = (TouchePav�)(arg0.getSource());

char c = touche.getSymbole();
traite(c);
}

/**
 * 
 * Ceci n'est pas une m�thode �v�nementielle. Elle porte ce nom par commodit�
 *
 * */
public void keyTyped(KeyEvent arg0)
{
char c = arg0.getKeyChar();
traite(c);
}

/**
 * Traitement de l'�v�nement : la frappe d'une touche (virtuelle ou physique) portant le symbole c
 * 
 * */
public abstract void traite(char c);

/**
 * Traite le cas du retour � l'�tat pr�c�dent
 * 
 * */
public boolean traiteRetour(char c)
{
if (c == 'c')
    {
    this.calculetteState.effaceFinR�sultat();
    return true;
    }
else 
    return false;
}

}
