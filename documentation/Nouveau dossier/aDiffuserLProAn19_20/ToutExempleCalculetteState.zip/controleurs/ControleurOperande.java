package exemplecoursstate.controleurs;

import exemplecoursstate.CalculetteState;

/**
 * Classe m�re de tous les contr�leurs d'op�rande
 * 
 * */
public abstract class ControleurOperande extends ControleurEtat
{

public ControleurOperande(CalculetteState calculetteState,
        ControleurEtat suivant, ControleurEtat retour)
{
super(calculetteState, suivant, retour);
}

public void traite(char c)
{
int x = c - '0';
if (0 <= x && x <= 9)
    this.traiteOp�rande(x);
}

/**
 * Traite le cas de la frappe d'une touche repr�sentant un chiffre de 0 � 9
 * 
 * */
protected abstract void traiteOp�rande(int x);
}
