package exemplecoursstate.controleurs;

import injectiondecode.mieux.*;

import exemplecoursstate.CalculetteState;

/**
 * g�re l'�tat "d�signation de l'op�rateur binaire"
 * 
 * */
public class ControleurOperateur extends ControleurEtat
{

public ControleurOperateur(CalculetteState calculetteState,
        ControleurEtat suivant, ControleurEtat retour)
{
super(calculetteState, suivant, retour);
}

public void traite(char c)
{
if (this.traiteRetour(c))   // cas du retour � l'�tat pr�c�dent 
    this.calculetteState.setContr�leurCourant(this.retour);
else
    {
    Operation op;
    op = this.r�sout(c); // reconnaissance de l'op�ration � effectuer
    
    if (op != null) // l'op�ration a �t� reconnue
        {
        this.calculetteState.setOp�ration(op);
        this.calculetteState.compl�teR�sultat(c);
        this.calculetteState.setContr�leurCourant(this.suivant);
        }
    }
}

/**
 * Reconnaissance de l'op�ration � effectuer
 * 
 * @param c : le symbole de l'op�ration, un op�rateur parmi + et *
 * @return l'op�ration � effectuer ou null si l'op�ration n'est pas reconnue
 * 
 * Remarque : l'algo de la m�thode est TRES maladroit. Il doit �tre remplac� par le DP COR dans une version finale
 * */
private Operation r�sout(char c)
{
if (c == '+')
    return new Plus();
if (c == '*')
    return new Fois();

return null;
}

}
