package exemplecoursobserver;
import exemplecoursabstractfactory.geometrie.*;

public class Fonctions
{
/**
 * calcule un point sur la cardio�de d'�quation :
 * x = 2t(1-t)cos(2PIt)
 * y = 2t(1-t)sin(2PIt)
 * 
 * on suppose que 0 <= t <= 1
 * 
 * */
public static Vecteur cardio�de(double t)
{
double r = 2*t*(1-t),teta = 2*Math.PI*t;
return new Vecteur(r*Math.cos(teta),r*Math.sin(teta));
}
}
