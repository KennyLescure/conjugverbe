package exemplecoursobserver;

import exemplecoursabstractfactory.geometrie.*;
public class InstantPosition
{
public double instant; // instant t
public Vecteur Position; // position sur la courbe � l'instant t. cf. trajectoire
/**
 * @param instant
 * @param position
 */
public InstantPosition(double instant, Vecteur position)
{
this.instant = instant;
Position = position;
}



}
