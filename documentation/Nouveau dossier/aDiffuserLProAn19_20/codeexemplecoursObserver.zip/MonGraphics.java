package exemplecoursobserver;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;
import java.util.Vector;

import exemplecoursabstractfactory.geometrie.Vecteur;

public class MonGraphics 
{
protected Graphics g;



/**
 * @return the g
 */
public Graphics getG()
{
return g;
}
/**
 * @param g
 */
public MonGraphics(Graphics g)
{
this.g = g;
}
public  void drawLine(Vecteur A, Vecteur B)
{
this.g.drawLine((int)A.x,(int)A.y,(int)B.x,(int)B.y);
}

public void fillPolygon(Vecteur [] t)
{
this.g.fillPolygon(Vecteur.toPolygon(t));
}

public  void drawString(String str, Point A)
{
this.g.drawString(str, A.x + 5, A.y + 10);
}


public void traceCourbe(Vector<Point> l)
{
int i;
for (i = 0; i < l.size(); ++i)    
    tracePoint(l.get(i),2);
}

public void tracePoint( Point p, int r)
{
int r2 = r*2;
this.g.fillOval(p.x-r,p.y-r, r2, r2);
}


public  void traceVecteur( Vecteur v, int r)
{
tracePoint(v.toPoint(),r);
}

public void traceRep�re( Point o, Point a, Point b, Point c, Point d)
{
this.g.drawLine(a.x, a.y, c.x, c.y);
this.g.drawLine(b.x, b.y, d.x, d.y);
tracePoint(a,2);
tracePoint(b,2);
tracePoint(c,2);
tracePoint(d,2);

drawString("(0,0)", o);
drawString("(1,0)", a);
drawString("(0,1)", b);
drawString("(-1,0)", c);
drawString("(0,-1)", d);


}
}

