package exemplecoursobserver;

public class TestTrajectoire
{

/**
 * @param args
 */
public static void main(String[] args) throws Exception
{
Trajectoire trajectoire = new Trajectoire(0.02,200);

VueTrajectoire vueTrajectoire = new VueTrajectoire("cardio�de");
VueRayon vueRayon = new VueRayon("rayon en fonction de t");
VueAbscisses vueAbscisses = new VueAbscisses();

trajectoire.addObserver(vueTrajectoire);
trajectoire.addObserver(vueRayon);
trajectoire.addObserver(vueAbscisses);

Thread t = new Thread(trajectoire);
vueTrajectoire.setVisible(true);
vueRayon.setVisible(true);

int stop;
System.out.println("tapez un caract�re + ENTREE pour lancer l'animation");
stop = System.in.read();


t.start();

}

}
