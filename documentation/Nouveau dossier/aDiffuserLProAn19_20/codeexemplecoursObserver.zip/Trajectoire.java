package exemplecoursobserver;
import exemplecoursabstractfactory.geometrie.*;

import java.util.Observable;

/**
 * 
 * Calcule la trajectoire d'un mobile sur une courbe param�trique plane d�crite par un param�tre t dans [0,1]
 * 
 * version tr�s maladroite : non param�tr�e par la courbe. La courbe est plac�e en "dur" dans le code
 * */
public class Trajectoire extends Observable implements Runnable
{
Vecteur p;
double t,pas;
int intervalle;



/**
 * @param pas : diff�rence entre 2 valeurs cons�cutives de t
 * @param intervalle : dur�e du sommeil (en ms) entre 2 �valuations cons�cutives de la position
 */
public Trajectoire( double pas, int intervalle)
{
this.p = null;
this.pas = pas;
this.intervalle = intervalle;
}


@Override
public void run()
{
InstantPosition instantPosition; // sera communiqu� aux observateurs � chaque changement
try
    {
    
    for ( t = 0; t <= 1; t+=pas)
        {
        p = Fonctions.cardio�de(t); // maladroit, il faut param�trer Trajectoire par la courbe � d�crire
        this.setChanged();          // indique que l'objet trajectoire a chang�
        instantPosition = new InstantPosition(t,p); 
        this.notifyObservers(instantPosition);    // pr�vient tous les observateurs enregistr�s que this a chang� et envoie (t,f(t))
        Thread.sleep(100);
        }
    }
catch (InterruptedException e)
    {
    // TODO Auto-generated catch block
    e.printStackTrace();
    }


}

}
