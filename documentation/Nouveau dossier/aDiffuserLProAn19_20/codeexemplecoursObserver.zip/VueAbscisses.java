package exemplecoursobserver;

import java.util.Observable;
import java.util.Observer;
import exemplecoursabstractfactory.geometrie.*;

public class VueAbscisses implements Observer
{

@Override
public void update(Observable arg0, Object arg1)
{
InstantPosition iP = (InstantPosition)arg1;
Vecteur position = iP.Position;
System.out.println(" x(t) = "+ position.x);

}

}
