package exemplecoursobserver;


import java.awt.*;
import java.util.*;


import exemplecoursabstractfactory.geometrie.*;

public abstract class VueGUI extends Frame implements Observer
{
Vector<Point> l;

Point o,a,b,c,d; // rep�re �cran
TransformationAffine t; // monde ---> �cran
TransformationAffine t_1; // �cran ---> monde
/**
     * @param arg0
     * @throws HeadlessException
     */
    public VueGUI(String arg0) throws HeadlessException
    {
    super(arg0);
    this.l = new Vector<Point>();   
    
 // la ligne qui suit est maladroite
    this.setSize(500, 500);
    this.setResizable(false);
    
    this.calculeTransformationsAffines();
    this.calculeRep�re();
    }

/**
 * Calculs n�cessaires � l'affichage de l'axe des abscisses et de l'axe des ordonn�es
 * 
 * 
 * */
private void calculeRep�re()
{
Vecteur O,A,B,C,D;
O = new Vecteur(0,0);
A = new Vecteur(1,0);
B = new Vecteur(0,1);
C = new Vecteur(-1,0);
D = new Vecteur(0,-1);

Vecteur Olocal,Alocal, Blocal, Clocal, Dlocal;

Olocal = t_1.applique(O);
Alocal = t_1.applique(A);
Blocal = t_1.applique(B);
Clocal = t_1.applique(C);
Dlocal = t_1.applique(D);


o = Olocal.toPoint();
a = Alocal.toPoint();
b = Blocal.toPoint();
c = Clocal.toPoint();
d = Dlocal.toPoint();
}

public void update(Observable arg0, Object arg1)
{
InstantPosition iP = (InstantPosition)arg1;
Vecteur position = this.extraitVecteur(iP);
Vecteur positionLocale = t_1.applique(position);
l.add( positionLocale.toPoint());
repaint();
}

protected abstract  Vecteur extraitVecteur(InstantPosition iP);

public void paint(Graphics g)
{
MonGraphics mG = new MonGraphics(g);
mG.traceRep�re(o,a,b,c,d);
mG.traceCourbe(l);
}

/**
 * Calcul des changements de rep�re entre le monde et l'�cran
 * */
protected void calculeTransformationsAffines()
{
Vecteur P1a, P2a, P1n, P2n;

// les 2 lignes qui suivent sont maladroites ; elles ne sont valables que pour la cardio�de

//P1a = new Vecteur(-0.25,-0.25);
//P2a = new Vecteur(0.25,0.25);
P1a = new Vecteur(-1,-1);
P2a = new Vecteur(1,1);

P1n = new Vecteur(30,this.getHeight()-30);
P2n = new Vecteur(this.getWidth()-30,30);

this.t = new TransformationAffine( P1a, P2a, P1n, P2n);

this.t_1 = t.r�ciproque();

}
}



