package exemplecoursobserver;

import java.awt.HeadlessException;
import java.util.Observer;

import exemplecoursabstractfactory.geometrie.Vecteur;

public class VueRayon extends VueGUI
{

public VueRayon(String arg0) throws HeadlessException
{
super(arg0);
}

@Override
protected Vecteur extraitVecteur(InstantPosition iP)
{
return new Vecteur(iP.instant,iP.Position.norme());
}


}
