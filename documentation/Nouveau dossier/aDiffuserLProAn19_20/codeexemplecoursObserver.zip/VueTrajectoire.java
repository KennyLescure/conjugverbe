package exemplecoursobserver;

import java.awt.*;
import java.util.*;

import exemplecoursabstractfactory.geometrie.*;

public class VueTrajectoire extends VueGUI
{


/**
     * @param arg0
     * @throws HeadlessException
     */
    public VueTrajectoire(String arg0) throws HeadlessException
    {
    super(arg0);
     
    }

@Override
protected Vecteur extraitVecteur(InstantPosition iP)
{
return iP.Position;
}





}



