package exemplecourschainofresp;

import java.util.*;

public class DicoAllemandFrancaisCOR extends DicoEtrangerFrancaisCOR
{
private Vector<String[]> l;

/**
     * @param suivant
     */
    public DicoAllemandFrancaisCOR(DicoEtrangerFrancaisCOR suivant)
    {
    super(suivant);
    String [] t ;
    l = new Vector<String[]>();
    t = new String[2];
    t[0] = "maus"; t[1] = "souris";
    l.add(t);
    t = new String[2];
    t[0] = "blum"; t[1] = "fleur";
    l.add(t);
    t = new String[2];
    t[0] = "hund"; t[1] = "chien";
    l.add(t);
    }
public String toString()
{
int i;
String r;
for( r = "", i = 0; i < l.size(); ++i)
    r+="("+l.get(i)[0]+", "+l.get(i)[1]+")";
return r;
}
@Override
protected String traduit2(String string)
{
int i;

for ( i = 0; i < l.size(); ++i)
    if (l.get(i)[0].equalsIgnoreCase(string))
        return l.get(i)[1];
return null;
}

}
