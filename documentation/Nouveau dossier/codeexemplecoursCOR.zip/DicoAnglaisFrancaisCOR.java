package exemplecourschainofresp;

public class DicoAnglaisFrancaisCOR extends DicoEtrangerFrancaisCOR
{
private static String [][] t = {{"Hello","Salut"},
                                {"Nice to meet you" ,"Enchant� de faire votre connaissance"},
                                {"Mind your own business","Occupez vous de vos affaires"},
                                {"turnip","navet"},{"mouse","souris"}};  
public DicoAnglaisFrancaisCOR(DicoEtrangerFrancaisCOR suivant)
{
super(suivant);

}

@Override
protected String traduit2(String string)
{
int i;
for ( i = 0; i < t.length; ++i)
    if (string.equalsIgnoreCase(t[i][0]))
        return t[i][1];
return null;
}

}
