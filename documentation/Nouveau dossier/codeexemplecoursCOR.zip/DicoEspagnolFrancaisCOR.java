package exemplecourschainofresp;

import java.util.*;

public class DicoEspagnolFrancaisCOR extends DicoEtrangerFrancaisCOR
{
Vector<String>  l1, l2;

public DicoEspagnolFrancaisCOR(DicoEtrangerFrancaisCOR suivant)
{
super(suivant);
l1 = new Vector<String>();
l2 = new Vector<String>();

l1.add("ratoncito");l2.add("souris");
l1.add("el coche de mis sue�os");l2.add("la voiture de mes r�ves");
l1.add("biscocho");l2.add("g�teau");
l1.add("perrito");l2.add("petit chien");
}

@Override
protected String traduit2(String string)
{
int i;

for ( i = 0; i < l1.size(); ++i)
    if (l1.get(i).equalsIgnoreCase(string)) return l2.get(i);
return null;
}

}
