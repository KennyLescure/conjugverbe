package exemplecourschainofresp;

public interface DicoEtrangerFrancais
{
/**
 * 
 * traduit string en fran�ais. String peut �tre un mot, un groupe nominal, une phrase, etc. �crite dans une langue �trang�re
 * 
 * */
public String traduit(String string);
}
