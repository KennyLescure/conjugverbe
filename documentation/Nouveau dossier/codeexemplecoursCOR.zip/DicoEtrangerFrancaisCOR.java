package exemplecourschainofresp;

public abstract class DicoEtrangerFrancaisCOR implements
        DicoEtrangerFrancais
{
protected DicoEtrangerFrancaisCOR suivant;



/**
 * @param suivant
 */
public DicoEtrangerFrancaisCOR(
        DicoEtrangerFrancaisCOR suivant)
{
this.suivant = suivant;
}

/**
 * @param suivant the suivant to set
 */
public void setSuivant(DicoEtrangerFrancaisCOR suivant)
{
this.suivant = suivant;
}


@Override
public String traduit(String string)
{
String r�sultat;
r�sultat = this.traduit1(string);

if (r�sultat != null)  // une traduction a �t� trouv�e
    return r�sultat;
else    // �chec du dictionnaire
    return string;      // solution par d�faut
}







/**
 * version si la liste est circulaire
 * 
 * */
/*
@Override
public String traduit(String string)
{
String r�sultat;
r�sultat = this.traduit1(string,this);

if (r�sultat != null)  // une traduction a �t� trouv�e
    return r�sultat;
else    // �chec du dictionnaire
    return string;      // solution par d�faut
}
*/

/**
 * traduction utilisant la cha�ne de responsabilit�. algo r�cursif et template
 * 
 * */
private String traduit1(String string)
{
String r�sultat;

r�sultat = traduit2(string); // ce traducteur tente de prendre en charge la traduction

if (r�sultat != null) // succ�s de ce traducteur
    return r�sultat;

else    // �chec de ce traducteur
    
    if (this.suivant != null) // puisque il y a un suivant, on lui confie la t�che de traduction
        return this.suivant.traduit1(string);
    else // c'�tait le dernier traducteur, c'est donc un �chec
        return null;

}


/**
 * traduction utilisant la cha�ne de responsabilit�. algo r�cursif et template. version liste circulaire
 * 
 * */
private String traduit1(String string, DicoEtrangerFrancaisCOR debut)
{
String r�sultat;

r�sultat = traduit2(string); // ce traducteur tente de prendre en charge la traduction

if (r�sultat != null) // succ�s de ce traducteur
    return r�sultat;

else    // �chec de ce traducteur
    
    if (this.suivant != debut) // puisque il y a un suivant, on lui confie la t�che de traduction
        return this.suivant.traduit1(string,debut);
    else // c'�tait le dernier traducteur, c'est donc un �chec
        return null;

}

/**
 * savoir-faire de l'un des traducteurs de la cha�ne
 * */
protected abstract String traduit2(String string);



} // DictionnaireEtrangerVersFrancaisCOR
