package exemplecourschainofresp;

import java.io.*;
public class TestDicoEtrangerFrancais
{

/**
 * @param args
 */
public static void main(String[] args) throws IOException
{
DicoEtrangerFrancais dicoEtrangerFran�ais;
DicoEtrangerFrancaisCOR  dicoAnglaisFran�ais, dicoAllemandFran�ais, dicoEspagnolFran�ais;


//on construit la cha�ne de responsabilit�. 
// Dans une version d�finitive, ceci devrait �tre r�alis� ailleurs � l'aide du design pattern FACADE
//version non circulaire
dicoAnglaisFran�ais = new DicoAnglaisFrancaisCOR(null);

dicoAllemandFran�ais = new DicoAllemandFrancaisCOR(dicoAnglaisFran�ais);

dicoEspagnolFran�ais = new DicoEspagnolFrancaisCOR(dicoAllemandFran�ais);

// dicoAnglaisFran�ais.setSuivant(dicoEspagnolFran�ais); // on referme la boucle si circulaire

dicoEtrangerFran�ais = dicoEspagnolFran�ais;

// le dictionnaire sera utilis� par l'interm�diaire de dicoEtrangerFran�ais qui pointe sur le 1er maillon de la cha�ne

// Dans la suite, le client (c-�-d main()) ignore la nature du dictionnaire, il ne doit conna�tre que l'interface 

System.out.println("Tapez la cha�ne � traduire en Fran�ais");
String donn�e, r�sultat;

BufferedReader clavier = new BufferedReader(new InputStreamReader(System.in));
donn�e  = clavier.readLine().trim();

r�sultat = dicoEtrangerFran�ais.traduit(donn�e);

System.out.println("La traduction de : "+ donn�e+" est : "+r�sultat);


}

}
