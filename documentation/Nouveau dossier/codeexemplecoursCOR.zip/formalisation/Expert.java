package exemplecourschainofresp.formalisation;

public interface Expert
{
public S r�soudre(D d);
}
