package exemplecourschainofresp.formalisation;

public abstract class ExpertCOR implements Expert
{
private ExpertCOR suivant;  // expert suivant dans la cha�ne

public ExpertCOR(ExpertCOR expertSuivant)
{
this.suivant = expertSuivant ;
}

public S r�soudre(D d)
{
S s = this.r�soudre1(d);        // cet expert tente de r�soudre le
//  probl�me

if  (s != null) // cet expert a trouv� une solution 
return s;

else            // �chec de l�expert

if  (this.suivant != null)  // le probl�me est transmis �   
// l�expert suivant
return this.suivant.r�soudre(d);

else    // cet expert est le dernier de la cha�ne

return null; // donc �chec de la cha�ne
}

public abstract S r�soudre1(D d) ;
}
