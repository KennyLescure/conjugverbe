package exo_shifumi_mediator.maladroit.modele;

/**
 * Dans tout jeu d'argent, il y a une banque qui vole un peu les joueurs maladroits
 * 
 * */
public class Banque
{
public double montant;

public Banque(double montant)
{
super();
this.montant = montant;
}

public Banque() { this(0);}

}
