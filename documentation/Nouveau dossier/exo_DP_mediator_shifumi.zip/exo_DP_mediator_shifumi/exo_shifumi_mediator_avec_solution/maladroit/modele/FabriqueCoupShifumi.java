package exo_shifumi_mediator.maladroit.modele;

import exo_shifumi_mediator.maladroit.modele.jeu.CoupShifumi;

public interface FabriqueCoupShifumi
{

public CoupShifumi creeCoupShifumi(String pseudoJoueur, double miseJouee, Banque banque);

}
