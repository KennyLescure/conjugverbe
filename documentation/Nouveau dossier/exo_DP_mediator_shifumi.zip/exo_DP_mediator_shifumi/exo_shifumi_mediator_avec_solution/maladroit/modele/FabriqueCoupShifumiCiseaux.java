package exo_shifumi_mediator.maladroit.modele;

import exo_shifumi_mediator.maladroit.modele.jeu.CoupShifumi;
import exo_shifumi_mediator.maladroit.modele.jeu.CoupShifumiCiseaux;

public class FabriqueCoupShifumiCiseaux implements FabriqueCoupShifumi
{

@Override
public CoupShifumi creeCoupShifumi(String pseudoJoueur, double miseJouee,
        Banque banque)
{
return new CoupShifumiCiseaux(pseudoJoueur, miseJouee, banque);
}

@Override
public String toString()
{
return "Ciseaux";
}

}
