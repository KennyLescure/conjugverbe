package exo_shifumi_mediator.maladroit.modele;

import exo_shifumi_mediator.maladroit.modele.jeu.CoupShifumi;

/**
 * repr�sente le d�roulement d'une partie de Shifumi
 * 
 * */
public class PartieShifumi
{
public CoupShifumi coupShifumi[];
public Banque banque;

public PartieShifumi()
{
this.coupShifumi = new CoupShifumi[2];
this.banque = new Banque();
}

}
