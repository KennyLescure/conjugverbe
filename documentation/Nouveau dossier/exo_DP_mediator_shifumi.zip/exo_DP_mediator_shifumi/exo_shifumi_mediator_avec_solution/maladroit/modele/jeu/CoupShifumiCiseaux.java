package exo_shifumi_mediator.maladroit.modele.jeu;

import exo_shifumi_mediator.maladroit.modele.Banque;

public class CoupShifumiCiseaux extends CoupShifumi
{

public CoupShifumiCiseaux(String pseudoJoueur, double miseJouee, Banque banque)
{
super(pseudoJoueur, miseJouee, banque);
}

/**
 * Les ciseaux gagnent contre la feuille
 * 
 * le vainqueur rafle la moiti� de la mise du perdant et re�oit en plus un cadeau de la banque qui s'�l�ve � 10% du montant de la banque
 * 
 * */
@Override public boolean gagne(CoupShifumi  coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiFeuille) ) return false;

double perteCoupShifumi = coupShifumi.miseJouee*0.5;
double perteBanque = 0.1*banque.montant;
this.miseJouee += perteCoupShifumi + perteBanque;

coupShifumi.miseJouee -= perteCoupShifumi;
this.banque.montant -= perteBanque;

return true;
}

/**
 * En cas de match null, c'est-�-dire ciseaux contre ciseaux, la banque prend � chaque  joueur la somme �quivalente � la mise la plus petite
 * 
 * */
@Override public boolean matchNull(CoupShifumi coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiCiseaux) ) return false;

double prise = Math.min(this.miseJouee, coupShifumi.miseJouee);
double gainBanque = 2*prise;

this.banque.montant += gainBanque;
this.miseJouee -= prise;
coupShifumi.miseJouee -= prise;

return true;
}

}


