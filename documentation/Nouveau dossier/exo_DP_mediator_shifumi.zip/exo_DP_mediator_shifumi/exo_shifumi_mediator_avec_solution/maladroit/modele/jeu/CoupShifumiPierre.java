package exo_shifumi_mediator.maladroit.modele.jeu;

import exo_shifumi_mediator.maladroit.modele.Banque;

public class CoupShifumiPierre extends CoupShifumi
{

public CoupShifumiPierre(String pseudoJoueur, double miseJouee, Banque banque)
{
super(pseudoJoueur, miseJouee, banque);
}

/**
 * La pierre gagne contre les ciseaux
 * 
 * le vainqueur rafle la mise du perdant
 * 
 * */
@Override
public boolean gagne(CoupShifumi  coupShifumi)
{
if (! (coupShifumi instanceof CoupShifumiCiseaux)) return false;

this.miseJouee += coupShifumi.miseJouee;

coupShifumi.miseJouee = 0;

return true;
}

/**
 * En cas de match null, c'est-�-dire pierre contre pierre, la banque rafle les mises des deux joueurs
 * 
 * */
@Override
public boolean matchNull(CoupShifumi coupShifumi)
{
if (! (coupShifumi instanceof CoupShifumiPierre)) return false;

this.banque.montant += this.miseJouee + coupShifumi.miseJouee;

this.miseJouee = coupShifumi.miseJouee = 0;

return true;
}

}


