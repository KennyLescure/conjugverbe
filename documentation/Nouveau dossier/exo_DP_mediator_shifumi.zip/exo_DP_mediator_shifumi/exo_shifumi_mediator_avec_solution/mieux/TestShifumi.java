package exo_shifumi_mediator.mieux;

import exo_shifumi_mediator.mieux.controleurs.EcouteurCoupJoue;
import exo_shifumi_mediator.mieux.controleurs.EcouteurArbitre;
import exo_shifumi_mediator.mieux.modele.FabriqueCoupShifumi;
import exo_shifumi_mediator.mieux.modele.FabriqueCoupShifumiCiseaux;
import exo_shifumi_mediator.mieux.modele.FabriqueCoupShifumiFeuille;
import exo_shifumi_mediator.mieux.modele.FabriqueCoupShifumiPierre;
import exo_shifumi_mediator.mieux.modele.PartieShifumi;
import exo_shifumi_mediator.mieux.modele.jeu.Arbitre;
import exo_shifumi_mediator.mieux.modele.jeu.AssemblageCOR;
import exo_shifumi_mediator.vues.CadreShifumi;
import outilsvues.EcouteurTerminaison;

public class TestShifumi
{

public static void main(String[] args)
{
FabriqueCoupShifumi fabriqueCoupShifumi[] = new FabriqueCoupShifumi[] {
                                                                      new FabriqueCoupShifumiPierre(), 
                                                                      new FabriqueCoupShifumiFeuille(), 
                                                                      new FabriqueCoupShifumiCiseaux()
                                                                      };

PartieShifumi partieShifumi = new PartieShifumi();

String labelsBoutons [] = new String[fabriqueCoupShifumi.length]; 

int i;
for (i = 0; i < fabriqueCoupShifumi.length; ++i) labelsBoutons[i] = fabriqueCoupShifumi[i].toString(); //{"Pierre", "Feuille","Ciseaux"};

CadreShifumi cadreShifumi = new CadreShifumi("jeu de shifumi classique. Version am�lior�e � l'aide du DP Mediator", labelsBoutons);

EcouteurTerminaison ecouteurTerminaison = new EcouteurTerminaison(cadreShifumi);

cadreShifumi.setVisible(true);
 
Arbitre arbitre = new Arbitre(AssemblageCOR.assemble());

EcouteurArbitre ecouteurRejouer = new EcouteurArbitre(arbitre,cadreShifumi.panneauResultat,partieShifumi,null, null); 
EcouteurCoupJoue ecouteurCoupJoue0 = new EcouteurCoupJoue(cadreShifumi.formulaireCoupJoueur0, partieShifumi, fabriqueCoupShifumi, ecouteurRejouer);
EcouteurCoupJoue ecouteurCoupJoue1 = new EcouteurCoupJoue(cadreShifumi.formulaireCoupJoueur1, partieShifumi, fabriqueCoupShifumi, ecouteurRejouer);
ecouteurRejouer.ecouteurCoupJoue0 = ecouteurCoupJoue0;
ecouteurRejouer.ecouteurCoupJoue1 = ecouteurCoupJoue1;
ecouteurCoupJoue0.init();
ecouteurCoupJoue1.init();
}

}
