package exo_shifumi_mediator.mieux.modele;

import exo_shifumi_mediator.mieux.modele.jeu.CoupShifumi;

public interface FabriqueCoupShifumi
{

public CoupShifumi creeCoupShifumi(String pseudoJoueur, double miseJouee, Banque banque);

}
