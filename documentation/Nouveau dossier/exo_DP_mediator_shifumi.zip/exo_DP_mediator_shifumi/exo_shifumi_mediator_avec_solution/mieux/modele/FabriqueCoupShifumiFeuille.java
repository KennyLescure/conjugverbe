package exo_shifumi_mediator.mieux.modele;

import exo_shifumi_mediator.mieux.modele.jeu.CoupShifumi;
import exo_shifumi_mediator.mieux.modele.jeu.CoupShifumiFeuille;

public class FabriqueCoupShifumiFeuille implements FabriqueCoupShifumi
{

@Override
public CoupShifumi creeCoupShifumi(String pseudoJoueur, double miseJouee,
        Banque banque)
{
return new CoupShifumiFeuille(pseudoJoueur, miseJouee, banque);
}

@Override
public String toString()
{
return "Feuille";
}

}
