package exo_shifumi_mediator.mieux.modele;

import exo_shifumi_mediator.mieux.modele.jeu.CoupShifumi;
import exo_shifumi_mediator.mieux.modele.jeu.CoupShifumiPierre;

public class FabriqueCoupShifumiPierre implements FabriqueCoupShifumi
{

@Override
public CoupShifumi creeCoupShifumi(String pseudoJoueur, double miseJouee,
        Banque banque)
{
return new CoupShifumiPierre(pseudoJoueur, miseJouee, banque);
}

@Override
public String toString()
{
return "Pierre";
}


}
