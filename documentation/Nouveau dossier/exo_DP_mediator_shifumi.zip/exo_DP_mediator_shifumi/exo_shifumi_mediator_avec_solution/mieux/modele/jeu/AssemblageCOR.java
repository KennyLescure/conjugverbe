package exo_shifumi_mediator.mieux.modele.jeu;

public class AssemblageCOR
{

/**
 * assemblage de la cha�ne de responsabilit�
 * */
public static MediatorShifumi  assemble()
{
MediatorCORShifumi mediatorCORShifumi = null;

mediatorCORShifumi = new MediatorCORShifumiPierreCiseaux(mediatorCORShifumi);
mediatorCORShifumi = new MediatorCORShifumiFeuillePierre(mediatorCORShifumi);
mediatorCORShifumi = new MediatorCORShifumiCiseauxFeuille(mediatorCORShifumi);
return mediatorCORShifumi;
}

}
