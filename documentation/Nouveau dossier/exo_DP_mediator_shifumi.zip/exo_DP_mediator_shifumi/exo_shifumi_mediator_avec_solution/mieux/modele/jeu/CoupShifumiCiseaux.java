package exo_shifumi_mediator.mieux.modele.jeu;

import exo_shifumi_mediator.mieux.modele.Banque;

public class CoupShifumiCiseaux extends CoupShifumi
{

public CoupShifumiCiseaux(String pseudoJoueur, double miseJouee, Banque banque)
{
super(pseudoJoueur, miseJouee, banque);
}

/**
 * En cas de match null, c'est-�-dire ciseaux contre ciseaux, la banque prend � chaque  joueur la somme �quivalente � la mise la plus petite
 * 
 * */
@Override public boolean matchNull(CoupShifumi coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiCiseaux) ) return false;

double prise = Math.min(this.miseJouee, coupShifumi.miseJouee);
double gainBanque = 2*prise;

this.banque.montant += gainBanque;
this.miseJouee -= prise;
coupShifumi.miseJouee -= prise;

return true;
}

}


