package exo_shifumi_mediator.mieux.modele.jeu;

import exo_shifumi_mediator.mieux.modele.Banque;

public class CoupShifumiFeuille extends CoupShifumi
{

public CoupShifumiFeuille(String pseudoJoueur, double miseJouee, Banque banque)
{
super(pseudoJoueur, miseJouee, banque);
}

/**
 * En cas de match null, c'est-�-dire feuille contre feuille, la banque rafle la moiti� de la mise des deux joueurs
 * 
 * */
@Override public boolean matchNull(CoupShifumi coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiFeuille)) return false;

double montantJoue = this.miseJouee + coupShifumi.miseJouee;
double gainBanque = montantJoue/2;
this.banque.montant += gainBanque;

this.miseJouee*=0.5; 
coupShifumi.miseJouee *= 0.5;

return true;
}

}




