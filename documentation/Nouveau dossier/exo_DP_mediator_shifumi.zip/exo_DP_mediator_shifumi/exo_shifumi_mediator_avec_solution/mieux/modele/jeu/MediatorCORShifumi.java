package exo_shifumi_mediator.mieux.modele.jeu;

/**
 * Mise en oeuvre du DP Mediator et du DP COR pour retrouver la relation "gagnant" entre 2 instances de coups de Shifumi
 * 
 * */
public abstract class MediatorCORShifumi implements MediatorShifumi
{
public MediatorCORShifumi suivant;

public MediatorCORShifumi(MediatorCORShifumi suivant)
{
super();
this.suivant = suivant;
}

@Override
public boolean gagne(CoupShifumi[] coupShifumi)
{
if (this.gagne1(coupShifumi)) 
   return true;

else 
   if (this.suivant != null) 
      return this.suivant.gagne(coupShifumi);
else
    return false;
}

/**
 * r�alise l'arbitrage d'une partie de Shifumi
 * 
 * reconna�t une et une seule situation "coup0 gagne contre coup1" (par exemple "Feuille gagne contre Pierre").
 * Cette expertise est r�alis�e par les classes d�riv�es de cette classe
 * 
 * @param coupShifumi[] : le tableau � deux �l�ments contenant les coups jou�s par le joueur 0 et par le joueur 1 
 *
 * @return true si la situation pr�cise o� coupShifumi[0] gagne contre coupShifumi[1] a �t� reconnue, 
 * sinon, c'est-�-dire si la situation n'a pas �t� reconnue, retourne false
 * 
 * Important :
 * si retourne true alors modifie les attributs miseJouee des �l�ments du tableau coupShifumi suivant les r�gles d�finies par les classes d�riv�es de MediatorCORShifumi
 * 
 */
protected abstract boolean gagne1(CoupShifumi[] coupShifumi);

}
