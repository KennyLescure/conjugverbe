package exo_shifumi_mediator.mieux.modele.jeu;

/**
 * reconna�t et g�re la relation Ciseaux  gagne contre Feuille
 *  
 *  avec coup0 == Ciseaux  et coup1 == Feuille
 * */
public class MediatorCORShifumiCiseauxFeuille extends MediatorCORShifumi
{

public MediatorCORShifumiCiseauxFeuille(MediatorCORShifumi suivant)
{
super(suivant);
}

/**
 * Les ciseaux gagnent contre la feuille
 * 
 * le vainqueur rafle la moiti� de la mise du perdant et re�oit en plus un cadeau de la banque qui s'�l�ve � 10% du montant de la banque
 * 
 * */
@Override
protected boolean gagne1(CoupShifumi[] coupShifumi)
{
if ( !( coupShifumi[0] instanceof CoupShifumiCiseaux) ) return false;
if ( !( coupShifumi[1] instanceof CoupShifumiFeuille) ) return false;

double perteCoupShifumi = coupShifumi[1].miseJouee*0.5;
double perteBanque = 0.1*coupShifumi[0].banque.montant;

coupShifumi[0].miseJouee += perteCoupShifumi + perteBanque;

coupShifumi[1].miseJouee -= perteCoupShifumi;
coupShifumi[0].banque.montant -= perteBanque;

return true;
}

}

/*/**
 * Les ciseaux gagnent contre la feuille
 * 
 * le vainqueur rafle la moiti� de la mise du perdant et re�oit en plus un cadeau de la banque qui s'�l�ve � 10% du montant de la banque
 * 
 * * /
@Override public boolean gagne(CoupShifumi  coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiFeuille) ) return false;

double perteCoupShifumi = coupShifumi.miseJouee*0.5;
double perteBanque = 0.1*banque.montant;
this.miseJouee += perteCoupShifumi + perteBanque;

coupShifumi.miseJouee -= perteCoupShifumi;
this.banque.montant -= perteBanque;

return true;
}*/