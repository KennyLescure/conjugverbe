package exo_shifumi_mediator.mieux.modele.jeu;

/**
 * reconna�t et g�re la relation Feuille gagne contre Pierre
 *  
 *  avec coup0 == Feuille et coup1 == Pierre
 * */
public class MediatorCORShifumiFeuillePierre extends MediatorCORShifumi
{

public MediatorCORShifumiFeuillePierre(MediatorCORShifumi suivant)
{
super(suivant);
}

/**
 * La feuille gagne contre la pierre
 * 
 * le vainqueur rafle la moiti� de la mise du perdant
 * 
 * */
@Override
protected boolean gagne1(CoupShifumi[] coupShifumi)
{
if ( !( coupShifumi[0] instanceof CoupShifumiFeuille)) return false;
if ( !( coupShifumi[1] instanceof CoupShifumiPierre))  return false;

double gain = coupShifumi[1].miseJouee/2;

coupShifumi[0].miseJouee += gain;
coupShifumi[1].miseJouee -= gain;

return true;
}

}


/*
/**
 * La feuille gagne contre la pierre
 * 
 * le vainqueur rafle la moiti� de la mise du perdant
 * 
 * * /
@Override public boolean gagne(CoupShifumi  coupShifumi)
{

if ( !( coupShifumi instanceof CoupShifumiPierre)) return false;

double gain = coupShifumi.miseJouee/2;
this.miseJouee += gain;

coupShifumi.miseJouee -= gain;

return true;
}*/