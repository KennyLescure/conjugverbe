package exo_shifumi_mediator.mieux.modele.jeu;

/**
 * reconna�t et g�re la relation Pierre gagne contre Ciseaux
 *  
 *  avec coup0 == Pierre et coup1 == Ciseaux
 * */
public class MediatorCORShifumiPierreCiseaux extends MediatorCORShifumi
{

public MediatorCORShifumiPierreCiseaux(MediatorCORShifumi suivant)
{
super(suivant);
}

/**
 * La pierre gagne contre les ciseaux
 * 
 * le vainqueur rafle la mise du perdant
 * 
 * */
@Override
protected boolean gagne1(CoupShifumi[] coupShifumi)
{
if (! (coupShifumi[0] instanceof  CoupShifumiPierre)) return false;
if (! (coupShifumi[1] instanceof CoupShifumiCiseaux)) return false;

coupShifumi[0].miseJouee += coupShifumi[1].miseJouee;

coupShifumi[1].miseJouee = 0;

return true;
}

}


/*/**
 * La pierre gagne contre les ciseaux
 * 
 * le vainqueur rafle la mise du perdant
 * 
 * * /
@Override
public boolean gagne(CoupShifumi  coupShifumi)
{
if (! (coupShifumi instanceof CoupShifumiCiseaux)) return false;

this.miseJouee += coupShifumi.miseJouee;

coupShifumi.miseJouee = 0;

return true;
}*/