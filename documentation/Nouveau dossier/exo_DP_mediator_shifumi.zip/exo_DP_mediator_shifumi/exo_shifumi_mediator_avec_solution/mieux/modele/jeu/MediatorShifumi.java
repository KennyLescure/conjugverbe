package exo_shifumi_mediator.mieux.modele.jeu;

public interface MediatorShifumi
{

/**
 * r�alise l'arbitrage d'une partie de Shifumi
 * 
 * @param coupShifumi[] : le tableau � deux �l�ments contenant les coups jou�s par le joueur 0 et par le joueur 1 
 *
 * @return true si la situation pr�cise o� coupShifumi[0] gagne contre coupShifumi[1] a �t� reconnue, 
 * sinon, c'est-�-dire si la situation n'a pas �t� reconnue, retourne false
 * 
 * Important :
 * si retourne true alors modifie les attributs miseJouee des �l�ments du tableau coupShifumi suivant les r�gles d�finies par les classes d�riv�es de MediatorShifumi
 * 
 */
public boolean gagne(CoupShifumi coupShifumi[]);
}
