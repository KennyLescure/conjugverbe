package exo_shifumi_mediator.vues;

import java.awt.Button;
import java.awt.HeadlessException;

/**
 * Bouton de choix de coup au shifumi
 * 
 * */
public class BoutonChoixCoup extends Button
{
public int i;  // indice du tableau dans lequel sera plac� le bouton, indique aussi le choix : pierre, feuille, ciseaux, etc.


/**
 * @param label : libell� du bouton
 * @param i : indice du tableau dans lequel sera plac� le bouton
 * @throws HeadlessException
 */
public BoutonChoixCoup(String label, int i) throws HeadlessException
{
super(label);
this.i = i;
}



}
