package exo_shifumi_mediator.vues;

import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Panel;

import outilsvues.Outils;


/**
 * vue g�n�rale du jeu de Shifumi � deux joueurs
 * 
 * */
public class CadreShifumi extends Frame
{
public FormulaireCoupJoueur formulaireCoupJoueur0;
public FormulaireCoupJoueur formulaireCoupJoueur1;
public PanneauResultat panneauResultat;

Panel haut/*, bas*/;

public CadreShifumi(String title, String labelsBoutons[]) throws HeadlessException
{
super(title);
double Ox, Oy, largeur,hauteur;

Ox = Oy = 1/3.0;
largeur = hauteur = 0.5;
Outils.place(this, Ox, Oy, largeur, hauteur);

this.setLayout(new GridLayout(2,1));
this.haut = new Panel();
this.add(this.haut);

/*this.bas = new Panel();
this.add(this.bas);*/

this.formulaireCoupJoueur0 = new FormulaireCoupJoueur(0, labelsBoutons);
this.haut.add(this.formulaireCoupJoueur0);
this.formulaireCoupJoueur1 = new FormulaireCoupJoueur(1, labelsBoutons);
this.haut.add(this.formulaireCoupJoueur1);

this.panneauResultat = new PanneauResultat();
this./*bas.*/add(this.panneauResultat);

}



}
