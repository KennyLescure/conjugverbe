package exo_shifumi_mediator.vues;

public class TestCadreShifumi
{

public TestCadreShifumi()
{
// TODO Auto-generated constructor stub
}

public static void main(String[] args)
{
String labelsBoutons [] = new String[]{"Pierre", "Feuille","Ciseaux"};
CadreShifumi cadreShifumi = new CadreShifumi("jeu de shifumi classique", labelsBoutons);
cadreShifumi.formulaireCoupJoueur0.init();
cadreShifumi.formulaireCoupJoueur1.init();
cadreShifumi.setVisible(true);

}

}
