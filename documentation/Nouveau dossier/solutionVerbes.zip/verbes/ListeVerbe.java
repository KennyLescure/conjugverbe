package verbes;

import java.util.Vector;

public class ListeVerbe
{
private Vector <Verbe> t;






/**
 * @param t
 */
public ListeVerbe()
{
this.t = new Vector<Verbe>();
}


/**
 * @return
 * @see java.util.Vector#size()
 */
public int size()
{
return t.size();
}


/**
 * @param arg0
 * @return
 * @see java.util.Vector#add(java.lang.Object)
 */
public boolean add(Verbe arg0)
{
return t.add(arg0);
}

/**
 * @param arg0
 * @return
 * @see java.util.Vector#get(int)
 */
public Verbe get(int arg0)
{
return t.get(arg0);
}


/**
 * 
 * conjugue tous les verbes de la liste � la 1�re personne du singulier
 * 
 * */
public String conjugue1�rePersonneSingulier() 
{
String s;
int i;

for ( s = "", i = 0; i < this.size(); ++i)
    s+=this.get(i).conjugue1�rePersonneSingulier()+"\n";
return s;
}


/**
 * 
 * conjugue tous les verbes de la liste � la 1�re personne du pluriel
 * 
 * */
public String conjugue1�rePersonnePluriel() 
{
String s;
int i;

for ( s = "", i = 0; i < this.size(); ++i)
    s+=this.get(i).conjugue1�rePersonnePluriel()+"\n";
return s;
}

/**
 * 
 * conjugue tous les verbes de la liste au participe pr�sent
 * 
 * */
public String conjugueParticipePr�sent() 
{
String s;
int i;

for ( s = "", i = 0; i < this.size(); ++i)
    s+=this.get(i).conjugueParticipePr�sent()+"\n";
return s;
}

/**
 * 
 * conjugue tous les verbes de la liste au participe pass�
 * 
 * */
public String conjugueParticipePass�() 
{
String s;
int i;

for ( s = "", i = 0; i < this.size(); ++i)
    s+=this.get(i).conjugueParticipePass�()+"\n";
return s;
}

/**
 * 
 * conjugue tous les verbes de la liste � la personne indiqu�e :
 * remplace avantageusement les 4 m�thodes pr�c�dentes
 * 
 * */
public String conjugue(PersonneConjuguee personneConjugu�e) 
{
String s;
int i;

for ( s = "", i = 0; i < this.size(); ++i)
    s += personneConjugu�e.conjugue(this.get(i))+"\n";
return s;
}



}//ListeVerbe
