package verbes;

/**
 * quelques outils utiles dans ce package
 * */
public class Outils
{
static private final String voyelles ="aeiouy";


public static boolean estUneVoyelle(char c)
{
char c1;
c1 = Character.toLowerCase(c);
int p = voyelles.indexOf(c1);

return p >= 0;
}



}
