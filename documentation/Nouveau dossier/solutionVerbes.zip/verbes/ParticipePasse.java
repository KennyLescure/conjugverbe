package verbes;

/**
 * 
 * repr�sente le participe pass�
 * 
 * */
public class ParticipePasse implements PersonneConjuguee
{

public String conjugue(Verbe verbe)
{
return verbe.conjugueParticipePass�();
}

}
