package verbes;

/**
 * 
 * Repr�sente le participe pr�sent
 * 
 * */
public class ParticipePresent implements PersonneConjuguee
{

public String conjugue(Verbe verbe)
{
return verbe.conjugueParticipePr�sent();
}

}
