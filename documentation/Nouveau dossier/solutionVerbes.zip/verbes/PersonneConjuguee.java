package verbes;

/**
 * repr�sente une personne au sens conjugaison
 * 
 * 
 * */
public interface PersonneConjuguee
{
/**
 * conjugue � la personne indiqu�e par this
 * */
String conjugue(Verbe verbe);
}
