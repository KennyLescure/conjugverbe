package verbes;

/**
 * 
 * repr�sente la 1�re personne du pluriel
 * */
public class PremierePersonnePluriel implements PersonneConjuguee
{

public String conjugue(Verbe verbe)
{
return verbe.conjugue1�rePersonnePluriel();
}

}
