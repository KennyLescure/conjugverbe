package verbes;

/**
 * 
 * Repr�sente la 1�re personne du singulier
 * 
 * */
public class PremierePersonneSingulier implements PersonneConjuguee
{

public String conjugue(Verbe verbe)
{
return verbe.conjugue1�rePersonneSingulier();
}

}
