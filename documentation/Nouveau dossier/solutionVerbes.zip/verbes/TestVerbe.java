package verbes;

public class TestVerbe
{

/**
 * @param args
 */
public static void main(String[] args)
{
// TODO Auto-generated method stub
ListeVerbe liste;


liste = new ListeVerbe();

liste.add(new Verbe1erGroupe("chanter"));
liste.add(new VerbeEnGer("arranger"));
liste.add(new VerbeEnOudre("absoudre"));
liste.add(new Verbe1erGroupe("aimer"));
liste.add(new Verbe2emeGroupe("finir"));
liste.add(new VerbeEnIndre("atteindre"));
liste.add(new Verbe2emeGroupe("atterrir"));
liste.add(new VerbeEnIndre("rejoindre"));
liste.add(new VerbeEnCer("tracer"));
liste.add(new VerbeEnAitre("dispara�tre"));


System.out.println(liste.conjugue1�rePersonneSingulier());
System.out.println(liste.conjugue1�rePersonnePluriel());
System.out.println(liste.conjugueParticipePr�sent());
System.out.println(liste.conjugueParticipePass�());

/*
 * A pr�sent, on va faire la m�me chose qu'avec l'appel aux 4 m�thodes pr�c�dentes, mais avec une seule m�thode
 * 
 * Ce sont les objets "personne copnjugu�e" qui indiquent � quelle personne, il faut conjuguer le verbe
 * */

System.out.
println("A pr�sent on fait la m�me chose mais en utilisant uniquement la m�thode conjugue() de la classe ListeVerbe :\n");

PersonneConjuguee p1, p2, p3, p4;

p1 = new PremierePersonneSingulier();
p2 = new PremierePersonnePluriel();
p3 = new ParticipePresent();
p4 = new ParticipePasse();

System.out.println(liste.conjugue(p1));
System.out.println(liste.conjugue(p2));
System.out.println(liste.conjugue(p3));
System.out.println(liste.conjugue(p4));


}

}
