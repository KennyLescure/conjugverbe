package verbes;

/**
 * les classes de ce package tentent de r�soudre le probl�me suivant : 
 * 
 * citer l'�nonc� de l'examen :......
 * 
 * 
 * 3. Conjugaison de verbes et Programmation Orient�e Objet - 6 points
Le but de cet exercice est de concevoir une classe  � liste de verbes � (appelons la ListeVerbes) qui poss�de 
quelques m�thodes de conjugaison.
La liste contient les infinitifs de n verbes des premiers et deuxi�mes groupes. Supposons qu�elle contienne les 10 
verbes suivants :
marcher, fr�mir, finir, chanter, nourrir, parler, planter, porter, rugir et ralentir.

La classe ListeVerbes doit poss�der les quatre m�thodes suivantes :

1.  String conjugue1�rePersonneSingulier() {�}
qui construit la conjugaison des n verbes � la premi�re personne du singulier de l�indicatif pr�sent. 
Pour la liste exemple, la m�thode construit donc la cha�ne suivante :
     
     Je marche
Je fr�mis
Je chante
...�
Chaque nouvelle conjugaison est plac�e sur une nouvelle ligne

2.  String conjugue1�rePersonnePluriel() {�}
qui construit la conjugaison des n verbes � la premi�re personne du pluriel de l�indicatif pr�sent.
Pour la liste exemple, la m�thode construit donc la cha�ne suivante :

Nous  marchons
Nous fr�missons
Nous chantons
��
chaque nouvelle conjugaison est plac�e sur une nouvelle ligne

3.  String conjugueParticipePr�sent() {�}
qui construit la conjugaison des n verbes au participe pr�sent.

Pour la liste exemple, la m�thode construit donc la cha�ne suivante :

En marchant
En fr�missant
En chantant
��
chaque nouvelle conjugaison est plac�e sur une nouvelle ligne

4.  String conjugueParticipePass�() {�}
qui construit la conjugaison des n verbes au participe pass�. 
Pour la liste exemple, la m�thode construit donc la cha�ne suivante :

march�
fr�mi
chant�
��
chaque nouvelle conjugaison est plac�e sur une nouvelle ligne


Il n�est pas n�cessaire de concevoir une classe liste de haut niveau avec des fonctions d�insertion et de 
suppression complexes : une simple classe contenant un tableau public dont la taille est fix�e � l�instanciation de 
l�objet fera l�affaire. Le tableau public pourra �tre rempli directement par main(). 

Pour r�aliser cette classe, il est utile de faire quelques rappels sur la conjugaison des verbes de la langue 
fran�aise (cf. annexe 1).

Contraintes � respecter pour r�aliser la classe ListeVerbes :
*   Toutes les m�thodes doivent �tre r�alis�es sans utiliser l�instruction if, ni l�instruction switch.
*   Il ne doit y avoir aucune redondance de code. Par exemple, les parties de cha�nes des conjugaisons, 
� Je� �Nous� et  �En�  ne doivent �tre tap�es qu�une seule fois.
*   D�finissez autant de classes, classes abstraites et interfaces que n�cessaire et r�fl�chissez bien aux 
relations entre ces classes. 
*   Ne d�finissez pas de classe inutile.
*   Vous �crirez aussi une m�thode main(�) qui construit la liste des 10 verbes donn�s en exemple et qui 
appelle les quatre m�thodes de la classe pour envoyer sur la console les conjugaisons.
G�n�ralisation 
Vous apporterez aussi votre r�flexion (en une dizaine de lignes ou � l�aide de diagrammes de classes) sur la 
question suivante : comment compl�ter l�application ensuite pour prendre en compte tous les verbes du troisi�me 
groupe avec toutes les cat�gories de verbes (verbes en a�tre comme para�tre, verbes en endre comme prendre, 
verbes en ttre comme mettre, verbes en oudre comme r�soudre, etc.) sans modifier la classe ListeVerbes, ni 
aucune de ses m�thodes ?

Annexe 1 : rappel de grammaire fran�aise
Pour r�aliser la classe ListeVerbes , il est utile de faire quelques rappels sur la conjugaison des verbes de la 
langue fran�aise :

Il y a trois groupes de verbes :
*   Verbes du 1er groupe : verbes dont l�infinitif se termine par � er�  (sauf le verbe aller qui est du 3�me 
groupe). 
    Exemple : lancer

*   Verbes du 2�me groupe : verbes dont l�infinitif se termine par � ir � et dont le participe pr�sent se 
termine par � issant �. 
    Exemple : r�fl�chir
    
*   Verbes du 3�me groupe : tous les autres verbes.  
    Exemples : lire, prendre, vouloir, mettre, craindre, joindre�
    
Conjugaison � la 1�re personne du singulier de l�indicatif pr�sent :
Pour les verbes du 1er groupe
Il faut ajouter e au radical du verbe 
Exemple 
Infinitif : chanter 
Radical : chant
Conjugaison : Je chante

Pour les verbes du 2�me groupe
Il faut ajouter is au radical du verbe 
Exemple 
Infinitif : p�lir
Radical : p�l
Conjugaison : Je p�lis

Pour les verbes du 3�me groupe
Il y a trop de cas particuliers pour �tablir une r�gle g�n�rale

Conjugaison � la 1�re personne du pluriel de l�indicatif pr�sent :
Pour les verbes du 1er groupe
Il faut ajouter ons au radical du verbe 
Exemple 
Infinitif : chanter 
Radical : chant
Conjugaison : Nous chantons

Pour les verbes du 2�me groupe
Il faut ajouter issons au radical du verbe 
Exemple 
Infinitif : p�lir
Radical : p�l
Conjugaison : Nous p�lissons

Pour les verbes du 3�me groupe
Il y a trop de cas particuliers pour �tablir une r�gle g�n�rale


Conjugaison au participe pass� :

Pour les verbes du 1er groupe
Il faut ajouter � au radical du verbe 
Exemple 
Infinitif : chanter 
Radical : chant
Conjugaison : chant�

Pour les verbes du 2�me groupe
Il faut ajouter i au radical du verbe 
Exemple 
Infinitif : p�lir
Radical : p�l
Conjugaison : p�li

Pour les verbes du 3�me groupe
Il y a trop de cas particuliers pour �tablir une r�gle g�n�rale

Conjugaison au participe pr�sent :
Pour tous  les verbes
A partir de la conjugaison du verbe � la 1�re personne du pluriel du pr�sent de l�indicatif, il faut remplacer la 
terminaison ons par ant 
Exemple 
Infinitif : lire 
Conjugaison � la 1�re personne du pluriel de l�indicatif pr�sent : Nous lisons
Conjugaison : En lisant


 * 
 * */


/**
 * repr�sente un verbe de la langue fran�aise. � ce niveau le groupe du verbe n'est pas connu
 * Les classes d�riv�es directes sont :
 * Verbe1erGroupe, Verbe2emeGroupe et Verbe3emeGroupe
 * 
 * Cette classe sert � mettre en oeuvre quelques conjugaisons au pr�sent de l'indicatif et au 
 * participe pass� et au participe pr�sent. Elle n'a pas l'ambition de g�rer tous les modes et 
 * tous les temps : Le probl�me est trop complexe pour �tre r�solu par cette simple petite classe 
 * 
 * @author Dominique Michel
 * 
 * */
public abstract class Verbe
{
protected String radical; /* vaut fr�m pour le verbe fr�mir, vaut mang pour le verbe manger...*/

/*
 * attention l'argument doit �tre le radical et non l'infinitif !
 * */
protected Verbe(String radical) {this.radical = radical.trim().toLowerCase();}

/**
 * @param infinitif: infinitif du verbe
 * @param messageErreur : message d'erreur � incorporer � l'exception si l'exception est lanc�e
 * @exception : lance une VerbeException si infinitif et terminaisonInfinitif() sont incompatibles 
 * 
 * */
protected Verbe( String infinitif,  String messageErreur) // throws VerbeException
{
String term = this.terminaisonInfinitif().toLowerCase().trim();     // peut �tre inutile de faire toLowerCase().trim()

String infi = infinitif.toLowerCase().trim();

if (!infi.endsWith(term)) 
   throw new VerbeException(messageErreur);
int l1 = infi.length();
int l2 = term.length();
int l = l1 - l2;
radical = infi.substring(0, l);
                                    //System.err.println(infinitif + " this.terminaisonInfinitif() = " + this.terminaisonInfinitif());
}

/**
 * si le verbe est "chanter" alors renvoie "je chante"
 * 
 * */
public String conjugue1�rePersonneSingulier() 
{
return this.pronomJe()+this.radical+this.terminaison1�rePersonneSingulier();
}

/**
 * si le verbe est "chanter" alors renvoie "nous chantons"
 * 
 * */
public String conjugue1�rePersonnePluriel() 
{
return "nous "+this.radical+this.terminaison1�rePersonnePluriel();
}

/**
 * si le verbe est "chanter" alors renvoie "chantant"
 * 
 * */
public String conjugueParticipePr�sent() 
{
String s, r;
int l;

//on conjugue � la 1�re personne du pluriel sans "nous"

s = this.radical+this.terminaison1�rePersonnePluriel(); 

l = s.length();
r = s.substring(0,l-3); // on coupe la terminaison "ons"

return "en "+ r+ "ant"; // on rajoute suffixe et pr�fixe
}

/**
 * si le verbe est "chanter" alors renvoie "chant�"
 * 
 * */
public String conjugueParticipePass�() 
{
return this.radical+this.terminaisonParticipePass�();
}

/**
 * si le verbe est "chanter" alors renvoie "je "
 * si le verbe est "aimer" alors renvoie "j'" 
 * 
 * */
public String pronomJe()
{
char c = this.radical.charAt(0);
if (Outils.estUneVoyelle(c))
    return "j'";
else
    return "je ";
}

//-- les m�thodes suivantes doivent �tre d�finies dans les classes d�riv�es

/**
 * terminaison pour la 1�re personne du singulier de l'indicatif pr�sent
 * 
 * exemple : e si le verbe est chanter, ir si le verbe est finir...
 * 
 * */
abstract public String terminaison1�rePersonneSingulier();

/**
 * terminaison pour la 1�re personne du pluriel de l'indicatif pr�sent
 * 
 * exemple : ons si le verbe est chanter, issons si le verbe est finir...
 * */
abstract public String terminaison1�rePersonnePluriel();

/**
 * terminaison pour le participe pass�
 * 
 * exemple : � si le verbe est chanter, i si le verbe est finir...
 * */
abstract public String terminaisonParticipePass�();

@Override
public String toString()
{
return  this.radical + this.terminaisonInfinitif();
}

/**
 * Terminaison de l'infinitif du verbe : "er", "ir", "a�tre", etc..
 * */
protected abstract String terminaisonInfinitif();


}//Verbe
