package verbes;

/**
 * 
 * repr�sente un verbe du 1er groupe comme : chanter, manger,...
 * 
 * */
public class Verbe1erGroupe extends Verbe
{
public Verbe1erGroupe( String infinitif) // throws VerbeException
{
super( infinitif, "verbe du premier groupe mal form�");
}


/**
 * @param infinitif
 * @param messageErreur
 */
protected Verbe1erGroupe(String infinitif, String messageErreur)
{
super(infinitif, messageErreur);
}


public String terminaison1�rePersonneSingulier()
{
return "e";
}

public String terminaison1�rePersonnePluriel()
{
return "ons";
}


public String terminaisonParticipePass�()
{
return "�";
}


@Override
protected String terminaisonInfinitif()
{
return "er";
}

}
