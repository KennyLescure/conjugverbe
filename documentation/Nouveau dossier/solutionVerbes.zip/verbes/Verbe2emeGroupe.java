package verbes;

/**
 * 
 * repr�sente un verbe du 2�me groupe comme : finir, fr�mir,...
 * 
 * */
public class Verbe2emeGroupe extends Verbe
{
public Verbe2emeGroupe(String infinitif)
{
super(infinitif, "verbe du 2�me groupe mal form�");
}

public String terminaison1�rePersonneSingulier()
{
return "is";
}

public String terminaison1�rePersonnePluriel()
{
return "issons";
}

public String terminaisonParticipePass�()
{
return "i";
}

@Override
protected String terminaisonInfinitif()
{
return "ir";
}

}
