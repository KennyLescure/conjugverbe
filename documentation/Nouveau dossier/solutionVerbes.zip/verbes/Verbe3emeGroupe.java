package verbes;

/*
 * repr�sente un verbe du 3�me groupe
 * */
public abstract class Verbe3emeGroupe extends Verbe
{


/**
 * @param infinitif
 * @param messageErreur
 */
public Verbe3emeGroupe(String infinitif, 
        String messageErreur)
{
super(infinitif, messageErreur);
}

    
    
}
