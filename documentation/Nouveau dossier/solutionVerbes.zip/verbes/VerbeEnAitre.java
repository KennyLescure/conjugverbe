package verbes;

/**
 * 
 * Cas des verbes comme : para�tre, conna�tre, ...
 * 
 * */
public class VerbeEnAitre extends Verbe3emeGroupe
{

public VerbeEnAitre(String infinitif)
{
super(infinitif, "verbe en \"a�tre\" mal form�");
}

@Override
public String terminaison1�rePersonneSingulier()
{
return "ais";
}

@Override
public String terminaison1�rePersonnePluriel()
{
return "aissons";
}

@Override
public String terminaisonParticipePass�()
{
return "u";
}

@Override
protected String terminaisonInfinitif()
{
return "a�tre";
}

}
