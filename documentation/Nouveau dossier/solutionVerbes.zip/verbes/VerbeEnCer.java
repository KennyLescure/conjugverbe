package verbes;

/**
 * 
 * repr�sente un verbe dont l'infinitif se termine par "cer" comme lancer, tracer, ...
 * 
 * */
public class VerbeEnCer extends Verbe1erGroupe
{

@Override
protected String terminaisonInfinitif()
{
return "cer";
}

public VerbeEnCer(String infinitif)
{
super(infinitif,"ce n'est pas un verbe en \"cer\"");
}

/* (non-Javadoc)
 * @see verbes.Verbe1erGroupe#terminaison1�rePersonnePluriel()
 */
@Override
public String terminaison1�rePersonnePluriel()
{
return "�"+super.terminaison1�rePersonnePluriel();
}

/* (non-Javadoc)
 * @see verbes.Verbe1erGroupe#terminaison1�rePersonneSingulier()
 */
@Override
public String terminaison1�rePersonneSingulier()
{
return "c"+super.terminaison1�rePersonneSingulier();
}

/* (non-Javadoc)
 * @see verbes.Verbe1erGroupe#terminaisonParticipePass�()
 */
@Override
public String terminaisonParticipePass�()
{
return "c"+super.terminaisonParticipePass�();
}




}// VerbeEnCer
