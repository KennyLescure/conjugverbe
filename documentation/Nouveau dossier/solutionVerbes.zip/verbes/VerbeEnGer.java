package verbes;
/**
 * repr�sente un verbe comme : manger, ranger,...
 * 
 * */
public class VerbeEnGer extends Verbe1erGroupe
{

public VerbeEnGer(String infinitif) throws VerbeException
{
super(infinitif);
char dernier;
dernier = this.radical.charAt(this.radical.length()-1);
//dernier = Character.toLowerCase(dernier);
if (dernier != 'g') throw new VerbeException("ce n'est pas un verbe en \"ger\"");
}

public String terminaison1�rePersonnePluriel()
{
return "e"+super.terminaison1�rePersonnePluriel();
}

}
