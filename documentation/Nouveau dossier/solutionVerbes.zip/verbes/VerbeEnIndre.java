package verbes;

/**
 * 
 * repr�sente un verbe comme : oindre, joindre, peindre, plaindre, atteindre, rejoindre,...
 * 
 * le radical est : infinitif sans "ndre"
 * 
 * */
public class VerbeEnIndre extends Verbe3emeGroupe
{

/**
 * @param infinitif
 * @param messageErreur
 */
public VerbeEnIndre(String infinitif)
{
super(infinitif, "verbe en \"indre\" mal form�");
}

public String terminaison1�rePersonneSingulier() {return "ins";}

public String terminaison1�rePersonnePluriel() {return "ignons";}


public String terminaisonParticipePass�() {return "int";}




@Override
protected String terminaisonInfinitif()
{
return "indre";
}

}
