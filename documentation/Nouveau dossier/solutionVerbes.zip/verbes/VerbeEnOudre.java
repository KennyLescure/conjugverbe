package verbes;

/**
 * 
 * repr�sente un verbe comme : r�soudre, dissoudre,...
 * 
 * le radical est : infinitif sans "udre"
 * 
 * */public class VerbeEnOudre extends Verbe3emeGroupe
{

/**
 * @param infinitif
 * @param terminaisonInfinitif
 * @param messageErreur
 */
public VerbeEnOudre(String infinitif)
{
super(infinitif, " verbe en \"oudre\" mal form�");
}

@Override
public String terminaison1�rePersonnePluriel()
{
return "olvons";
}

@Override
public String terminaison1�rePersonneSingulier()
{
return "ous";
}

@Override
public String terminaisonParticipePass�()
{
return "olu";
}



@Override
protected String terminaisonInfinitif()
{
return "oudre";
}

}
