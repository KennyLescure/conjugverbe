package verbes;

/**
 * erreur sur la classification d'un verbe lors de l'instantiation
 * 
 * */
public class VerbeException extends IllegalArgumentException
{
public VerbeException()
{
super("erreur sur la classification d'un verbe lors de l'instantiation");
}

public VerbeException(String message)
{
super(message);
}

}
